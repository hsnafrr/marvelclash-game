import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { useTexture } from '@react-three/drei';
import * as THREE from 'three';

export default function Arena() {
  const groupRef = useRef<THREE.Group>(null);
  const skyRef = useRef<THREE.Mesh>(null);
  const cityRef = useRef<THREE.Group>(null);
  
  const asphaltTexture = useTexture('/textures/asphalt.png');
  
  // Configure textures for New York street theme
  asphaltTexture.wrapS = asphaltTexture.wrapT = THREE.RepeatWrapping;
  asphaltTexture.repeat.set(4, 10);

  useFrame((state) => {
    if (groupRef.current) {
      // Subtle arena animation
      groupRef.current.rotation.y = Math.sin(state.clock.elapsedTime * 0.1) * 0.001;
    }
    
    // Animate night sky
    if (skyRef.current && skyRef.current.material instanceof THREE.MeshBasicMaterial) {
      skyRef.current.material.color.setHSL(0.6, 0.3, 0.05 + Math.sin(state.clock.elapsedTime * 0.1) * 0.02);
    }
    
    // Subtle city building sway
    if (cityRef.current) {
      cityRef.current.children.forEach((building, index) => {
        if (building instanceof THREE.Mesh) {
          building.rotation.z = Math.sin(state.clock.elapsedTime * 0.2 + index) * 0.005;
        }
      });
    }
  });

  return (
    <group ref={groupRef}>
      {/* Night Sky Background */}
      <mesh ref={skyRef} position={[0, 25, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[100, 100]} />
        <meshBasicMaterial color="#0a0a2e" />
      </mesh>

      {/* Main battlefield - New York street */}
      <mesh position={[0, -0.1, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[20, 30]} />
        <meshLambertMaterial color="#2a2a2a" map={asphaltTexture} />
      </mesh>

      {/* Street lanes with white markings */}
      <mesh position={[-6, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.3, 30]} />
        <meshBasicMaterial color="#ffffff" opacity={0.8} transparent />
      </mesh>
      
      <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.3, 30]} />
        <meshBasicMaterial color="#ffffff" opacity={0.8} transparent />
      </mesh>
      
      <mesh position={[6, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[0.3, 30]} />
        <meshBasicMaterial color="#ffffff" opacity={0.8} transparent />
      </mesh>

      {/* Street crosswalks */}
      <mesh position={[0, 0.03, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[12, 1]} />
        <meshBasicMaterial color="#ffffff" opacity={0.6} transparent />
      </mesh>
      
      <mesh position={[0, 0.03, 8]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[12, 1]} />
        <meshBasicMaterial color="#ffffff" opacity={0.6} transparent />
      </mesh>
      
      <mesh position={[0, 0.03, -8]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[12, 1]} />
        <meshBasicMaterial color="#ffffff" opacity={0.6} transparent />
      </mesh>

      {/* Side buildings for NYC atmosphere */}
      <group ref={cityRef}>
        {/* Left side buildings */}
        <mesh position={[-12, 3, 5]} castShadow>
          <boxGeometry args={[3, 6, 4]} />
          <meshLambertMaterial color="#1a1a1a" />
        </mesh>
        <mesh position={[-12, 2, 0]} castShadow>
          <boxGeometry args={[3, 4, 3]} />
          <meshLambertMaterial color="#252525" />
        </mesh>
        <mesh position={[-12, 4, -5]} castShadow>
          <boxGeometry args={[3, 8, 4]} />
          <meshLambertMaterial color="#1a1a1a" />
        </mesh>
        
        {/* Right side buildings */}
        <mesh position={[12, 3, 5]} castShadow>
          <boxGeometry args={[3, 6, 4]} />
          <meshLambertMaterial color="#1a1a1a" />
        </mesh>
        <mesh position={[12, 2, 0]} castShadow>
          <boxGeometry args={[3, 4, 3]} />
          <meshLambertMaterial color="#252525" />
        </mesh>
        <mesh position={[12, 4, -5]} castShadow>
          <boxGeometry args={[3, 8, 4]} />
          <meshLambertMaterial color="#1a1a1a" />
        </mesh>
        
        {/* Background buildings */}
        <mesh position={[0, 8, 20]} castShadow>
          <boxGeometry args={[6, 16, 3]} />
          <meshLambertMaterial color="#0f0f0f" />
        </mesh>
        <mesh position={[0, 8, -20]} castShadow>
          <boxGeometry args={[6, 16, 3]} />
          <meshLambertMaterial color="#0f0f0f" />
        </mesh>
      </group>

      {/* Building windows (lit windows for night effect) */}
      {useMemo(() => 
        Array.from({ length: 20 }, (_, i) => ({
          id: i,
          position: [
            -12 + (i * 1234567 % 1000) / 1000 * 24, 
            2 + (i * 9876543 % 1000) / 1000 * 4, 
            -10 + (i * 5432109 % 1000) / 1000 * 20
          ] as [number, number, number],
          opacity: 0.7 + (i * 1111111 % 1000) / 1000 * 0.3
        })), []
      ).map((window) => (
        <mesh key={window.id} position={window.position}>
          <planeGeometry args={[0.3, 0.4]} />
          <meshBasicMaterial 
            color="#ffdd44" 
            opacity={window.opacity} 
            transparent 
          />
        </mesh>
      ))}

      {/* Street lights */}
      <mesh position={[-8, 3, 10]}>
        <cylinderGeometry args={[0.05, 0.05, 3]} />
        <meshLambertMaterial color="#444444" />
      </mesh>
      <mesh position={[-8, 4.8, 10]}>
        <sphereGeometry args={[0.2]} />
        <meshBasicMaterial color="#fff8dc" />
      </mesh>
      
      <mesh position={[8, 3, 10]}>
        <cylinderGeometry args={[0.05, 0.05, 3]} />
        <meshLambertMaterial color="#444444" />
      </mesh>
      <mesh position={[8, 4.8, 10]}>
        <sphereGeometry args={[0.2]} />
        <meshBasicMaterial color="#fff8dc" />
      </mesh>

      {/* New York night lighting setup */}
      <ambientLight intensity={0.2} color="#1a1a2e" />
      <directionalLight 
        position={[-5, 15, 10]} 
        intensity={0.3}
        color="#87ceeb"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
      />
      
      {/* Street lighting */}
      <pointLight position={[-8, 5, 10]} intensity={0.8} color="#fff8dc" distance={8} />
      <pointLight position={[8, 5, 10]} intensity={0.8} color="#fff8dc" distance={8} />
      
      {/* Avengers Tower area lighting (hero side) */}
      <pointLight position={[0, 8, 15]} intensity={1.2} color="#4080ff" distance={12} />
      
      {/* Hydra Base area lighting (villain side) */}
      <pointLight position={[0, 8, -15]} intensity={1.2} color="#00ff00" distance={12} />
    </group>
  );
}
