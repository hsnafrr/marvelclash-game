export interface Character {
  id: string;
  name: string;
  faction: 'hero' | 'villain';
  cost: number;
  hp: number;
  damage: number;
  speed: number; // tiles per second
  range: 'short' | 'medium' | 'long';
  ability?: string;
  movementType: 'hover' | 'walk' | 'float' | 'fly' | 'crawl' | 'teleport' | 'glide' | 'phase';
  abilityType: 'damage' | 'aoe' | 'stun' | 'buff' | 'summon' | 'special';
  image?: string;
}

export const heroes: Character[] = [
  {
    id: 'iron-man',
    name: 'Iron Man',
    faction: 'hero',
    cost: 5,
    hp: 1200,
    damage: 180,
    speed: 1.2,
    range: 'long',
    ability: 'Unibeam: Piercing laser that damages all enemies in a line',
    movementType: 'hover',
    abilityType: 'damage'
  },
  {
    id: 'captain-america',
    name: 'Captain America',
    faction: 'hero',
    cost: 4,
    hp: 1500,
    damage: 120,
    speed: 1.2,
    range: 'short',
    ability: 'Shield Throw: Stuns target for 2 seconds',
    movementType: 'walk',
    abilityType: 'stun'
  },
  {
    id: 'thor',
    name: 'Thor',
    faction: 'hero',
    cost: 7,
    hp: 2200,
    damage: 250,
    speed: 0.8,
    range: 'short',
    ability: 'Lightning Storm: AoE damage around Thor',
    movementType: 'walk',
    abilityType: 'aoe'
  },
  {
    id: 'hulk',
    name: 'Hulk',
    faction: 'hero',
    cost: 8,
    hp: 3000,
    damage: 300,
    speed: 0.8,
    range: 'short',
    ability: 'Rage Mode: +50% damage and speed for 5 seconds',
    movementType: 'walk',
    abilityType: 'buff'
  },
  {
    id: 'black-widow',
    name: 'Black Widow',
    faction: 'hero',
    cost: 3,
    hp: 800,
    damage: 100,
    speed: 1.8,
    range: 'short',
    ability: 'Taser Shock: Stuns and deals bonus damage',
    movementType: 'walk',
    abilityType: 'stun'
  },
  {
    id: 'hawkeye',
    name: 'Hawkeye',
    faction: 'hero',
    cost: 2,
    hp: 600,
    damage: 80,
    speed: 1.8,
    range: 'long',
    ability: 'Explosive Arrow: AoE damage on impact',
    movementType: 'walk',
    abilityType: 'aoe'
  },
  {
    id: 'spider-man',
    name: 'Spider-Man',
    faction: 'hero',
    cost: 5,
    hp: 1200,
    damage: 150,
    speed: 1.8,
    range: 'short',
    ability: 'Web Shot: Immobilizes target for 3 seconds',
    movementType: 'walk',
    abilityType: 'stun'
  },
  {
    id: 'doctor-strange',
    name: 'Doctor Strange',
    faction: 'hero',
    cost: 6,
    hp: 1300,
    damage: 200,
    speed: 1.2,
    range: 'medium',
    ability: 'Time Freeze: Slows all enemies in area',
    movementType: 'float',
    abilityType: 'aoe'
  },
  {
    id: 'black-panther',
    name: 'Black Panther',
    faction: 'hero',
    cost: 4,
    hp: 1400,
    damage: 160,
    speed: 1.8,
    range: 'short',
    ability: 'Kinetic Charge: Next attack deals double damage',
    movementType: 'walk',
    abilityType: 'buff'
  },
  {
    id: 'scarlet-witch',
    name: 'Scarlet Witch',
    faction: 'hero',
    cost: 7,
    hp: 1600,
    damage: 240,
    speed: 1.2,
    range: 'long',
    ability: 'Reality Warp: Pushback AoE that damages enemies',
    movementType: 'float',
    abilityType: 'aoe'
  },
  {
    id: 'vision',
    name: 'Vision',
    faction: 'hero',
    cost: 6,
    hp: 1500,
    damage: 180,
    speed: 1.2,
    range: 'long',
    ability: 'Phase Shift: Becomes untargetable for 2 seconds',
    movementType: 'phase',
    abilityType: 'special'
  },
  {
    id: 'ant-man',
    name: 'Ant-Man',
    faction: 'hero',
    cost: 3,
    hp: 700,
    damage: 90,
    speed: 1.8,
    range: 'short',
    ability: 'Shrink Swarm: Summons 3 mini Ant-Men',
    movementType: 'walk',
    abilityType: 'summon'
  },
  {
    id: 'captain-marvel',
    name: 'Captain Marvel',
    faction: 'hero',
    cost: 8,
    hp: 2400,
    damage: 280,
    speed: 1.2,
    range: 'long',
    ability: 'Supernova Strike: Massive AoE explosion',
    movementType: 'hover',
    abilityType: 'aoe'
  },
  {
    id: 'falcon',
    name: 'Falcon',
    faction: 'hero',
    cost: 3,
    hp: 900,
    damage: 110,
    speed: 1.8,
    range: 'medium',
    ability: 'Drone Strike: Calls in aerial support',
    movementType: 'fly',
    abilityType: 'summon'
  },
  {
    id: 'winter-soldier',
    name: 'Winter Soldier',
    faction: 'hero',
    cost: 4,
    hp: 1300,
    damage: 140,
    speed: 1.2,
    range: 'medium',
    ability: 'Arm Punch: Knockback attack with bonus damage',
    movementType: 'walk',
    abilityType: 'damage'
  }
];

export const villains: Character[] = [
  {
    id: 'thanos',
    name: 'Thanos',
    faction: 'villain',
    cost: 8,
    hp: 3200,
    damage: 350,
    speed: 0.8,
    range: 'short',
    ability: 'Snap: Instantly removes one random enemy troop',
    movementType: 'walk',
    abilityType: 'special'
  },
  {
    id: 'loki',
    name: 'Loki',
    faction: 'villain',
    cost: 5,
    hp: 1100,
    damage: 140,
    speed: 1.8,
    range: 'medium',
    ability: 'Illusion Clone: Creates a decoy that confuses enemies',
    movementType: 'walk',
    abilityType: 'summon'
  },
  {
    id: 'ultron',
    name: 'Ultron',
    faction: 'villain',
    cost: 6,
    hp: 1500,
    damage: 180,
    speed: 1.2,
    range: 'long',
    ability: 'Drone Army: Summons 2 attack drones',
    movementType: 'hover',
    abilityType: 'summon'
  },
  {
    id: 'red-skull',
    name: 'Red Skull',
    faction: 'villain',
    cost: 4,
    hp: 1200,
    damage: 130,
    speed: 1.2,
    range: 'medium',
    ability: 'Hydra Rally: Buffs all nearby villain allies',
    movementType: 'walk',
    abilityType: 'buff'
  },
  {
    id: 'hela',
    name: 'Hela',
    faction: 'villain',
    cost: 7,
    hp: 2000,
    damage: 220,
    speed: 1.2,
    range: 'long',
    ability: 'Summon Undead: Spawns skeleton minions',
    movementType: 'float',
    abilityType: 'summon'
  },
  {
    id: 'dormammu',
    name: 'Dormammu',
    faction: 'villain',
    cost: 8,
    hp: 2600,
    damage: 320,
    speed: 0.8,
    range: 'long',
    ability: 'Dark Inferno: Massive AoE fire damage',
    movementType: 'float',
    abilityType: 'aoe'
  },
  {
    id: 'venom',
    name: 'Venom',
    faction: 'villain',
    cost: 5,
    hp: 1600,
    damage: 180,
    speed: 1.8,
    range: 'short',
    ability: 'Symbiote Leap: Jumps to target with stun',
    movementType: 'crawl',
    abilityType: 'stun'
  },
  {
    id: 'green-goblin',
    name: 'Green Goblin',
    faction: 'villain',
    cost: 4,
    hp: 1000,
    damage: 150,
    speed: 1.8,
    range: 'long',
    ability: 'Glider Rush: High-speed charge attack',
    movementType: 'glide',
    abilityType: 'damage'
  },
  {
    id: 'mysterio',
    name: 'Mysterio',
    faction: 'villain',
    cost: 3,
    hp: 800,
    damage: 90,
    speed: 1.2,
    range: 'medium',
    ability: 'Smoke Screen: Creates decoys and confusion',
    movementType: 'walk',
    abilityType: 'summon'
  },
  {
    id: 'magneto',
    name: 'Magneto',
    faction: 'villain',
    cost: 7,
    hp: 1800,
    damage: 250,
    speed: 1.2,
    range: 'long',
    ability: 'Magnetic Storm: Pulls and damages metal enemies',
    movementType: 'float',
    abilityType: 'aoe'
  },
  {
    id: 'kingpin',
    name: 'Kingpin',
    faction: 'villain',
    cost: 6,
    hp: 2200,
    damage: 200,
    speed: 0.8,
    range: 'short',
    ability: 'Body Slam: AoE knockback attack',
    movementType: 'walk',
    abilityType: 'aoe'
  },
  {
    id: 'killmonger',
    name: 'Killmonger',
    faction: 'villain',
    cost: 5,
    hp: 1500,
    damage: 170,
    speed: 1.8,
    range: 'short',
    ability: 'Tactical Rush: Dash attack with critical hit chance',
    movementType: 'walk',
    abilityType: 'damage'
  },
  {
    id: 'ronan',
    name: 'Ronan',
    faction: 'villain',
    cost: 7,
    hp: 2000,
    damage: 230,
    speed: 1.2,
    range: 'long',
    ability: 'Orb Beam: Line AoE energy blast',
    movementType: 'walk',
    abilityType: 'aoe'
  },
  {
    id: 'yellowjacket',
    name: 'Yellowjacket',
    faction: 'villain',
    cost: 3,
    hp: 700,
    damage: 110,
    speed: 1.8,
    range: 'short',
    ability: 'Shrink Rush: Becomes untargetable while attacking',
    movementType: 'teleport',
    abilityType: 'special'
  },
  {
    id: 'abomination',
    name: 'Abomination',
    faction: 'villain',
    cost: 7,
    hp: 2800,
    damage: 260,
    speed: 0.8,
    range: 'short',
    ability: 'Rampage: AoE damage buff that increases over time',
    movementType: 'walk',
    abilityType: 'buff'
  }
];

export const allCharacters = [...heroes, ...villains];

export const getCharacterById = (id: string): Character | undefined => {
  return allCharacters.find(char => char.id === id);
};

export const getCharactersByFaction = (faction: 'hero' | 'villain'): Character[] => {
  return allCharacters.filter(char => char.faction === faction);
};

export const getCharactersByCost = (cost: number): Character[] => {
  return allCharacters.filter(char => char.cost === cost);
};
