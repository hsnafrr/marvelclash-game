import { useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { useBattle } from '../../lib/stores/useBattle';
import { useDeck } from '../../lib/stores/useDeck';
import { useGame } from '../../lib/stores/useGame';
import { GameScreen } from '../../App';
import Arena from '../game/Arena';
import Tower from '../game/Tower';
import Character from '../game/Character';
import BattleUI from '../game/BattleUI';
import { startBattle, updateBattle } from '../../lib/gameLogic';
import { updateAI } from '../../lib/ai';

interface BattleScreenProps {
  onNavigate: (screen: GameScreen) => void;
}

export default function BattleScreen({ onNavigate }: BattleScreenProps) {
  const { start } = useGame();
  const { selectedDeck } = useDeck();
  const { 
    towers, 
    deployedCharacters, 
    timeRemaining, 
    battleResult,
    isInitialized 
  } = useBattle();

  // Initialize battle
  useEffect(() => {
    if (!isInitialized) {
      startBattle(selectedDeck);
      start();
    }
  }, [isInitialized, selectedDeck, start]);

  // Game loop
  useEffect(() => {
    if (!isInitialized || battleResult) return;

    const gameLoop = setInterval(() => {
      updateBattle();
      updateAI();
    }, 100); // 10 FPS game logic

    return () => clearInterval(gameLoop);
  }, [isInitialized, battleResult]);

  // Handle battle end
  useEffect(() => {
    if (battleResult) {
      setTimeout(() => {
        onNavigate('result');
      }, 2000);
    }
  }, [battleResult, onNavigate]);

  if (!isInitialized) {
    return (
      <div className="w-full h-full bg-black flex items-center justify-center">
        <div className="text-white text-2xl">Preparing Battle...</div>
      </div>
    );
  }

  return (
    <div className="w-full h-full relative">
      {/* 3D Arena */}
      <Canvas
        shadows
        camera={{
          position: [0, 12, 15],
          fov: 45,
          near: 0.1,
          far: 1000
        }}
        gl={{
          antialias: true,
          powerPreference: "default"
        }}
      >
        <color attach="background" args={["#0a0a0a"]} />
        
        {/* Arena */}
        <Arena />
        
        {/* Towers */}
        {towers.map((tower) => (
          <Tower
            key={tower.id}
            type={tower.type}
            variant={tower.variant}
            position={tower.position}
            id={tower.id}
          />
        ))}
        
        {/* Characters */}
        {deployedCharacters.map((char) => (
          <Character
            key={char.id}
            character={char.character}
            position={char.position}
            id={char.id}
            team={char.team}
          />
        ))}
      </Canvas>

      {/* Battle UI Overlay */}
      <BattleUI />

      {/* Battle result overlay */}
      {battleResult && (
        <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 text-center shadow-2xl">
            <h2 className={`text-4xl font-bold mb-4 ${
              battleResult.winner === 'hero' ? 'text-blue-600' : 
              battleResult.winner === 'villain' ? 'text-red-600' : 'text-gray-600'
            }`}>
              {battleResult.winner === 'hero' ? 'VICTORY!' : 
               battleResult.winner === 'villain' ? 'DEFEAT!' : 'DRAW!'}
            </h2>
            <p className="text-gray-600 mb-4">{battleResult.reason}</p>
            <div className="text-sm text-gray-500">
              Returning to results in 2 seconds...
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
