import { useBattle, DeployedCharacter, Tower } from './stores/useBattle';
import { useDeck } from './stores/useDeck';
import { Character } from '../data/characters';

// Initialize battle with selected deck
export const startBattle = (playerDeck: Character[]) => {
  const { initializeBattle } = useBattle.getState();
  const { initializeBattleDeck } = useDeck.getState();
  
  initializeBattle();
  initializeBattleDeck(playerDeck);
};

// Deploy a character to the battlefield
export const deployCharacter = (character: Character, position: [number, number, number], team: 'hero' | 'villain'): string => {
  const { deployCharacter: deploy } = useBattle.getState();
  return deploy(character, position, team);
};

// Main battle update loop
export const updateBattle = () => {
  const deltaTime = 0.1; // 100ms update interval
  
  updateTime(deltaTime);
  updateEnergy(deltaTime);
  updateCharacterMovement(deltaTime);
  updateCombat(deltaTime);
  updateTowerCombat(deltaTime);
};

// Update battle timer
const updateTime = (deltaTime: number) => {
  const { updateTime } = useBattle.getState();
  updateTime(deltaTime);
};

// Update energy regeneration
const updateEnergy = (deltaTime: number) => {
  const { updateEnergy } = useBattle.getState();
  updateEnergy(deltaTime);
};

// Update character movement and AI
const updateCharacterMovement = (deltaTime: number) => {
  const { deployedCharacters, towers, updateCharacterPosition } = useBattle.getState();
  
  deployedCharacters.forEach(char => {
    if (char.hp <= 0) return;
    
    // Find target - nearest enemy or tower
    const target = findNearestTarget(char);
    if (!target) return;
    
    const distance = getDistance(char.position, target.position);
    const attackRange = getAttackRange(char.character.range);
    
    // Move towards target if not in range
    if (distance > attackRange) {
      const direction = normalize([
        target.position[0] - char.position[0],
        0,
        target.position[2] - char.position[2]
      ]);
      
      const moveSpeed = char.character.speed * deltaTime;
      const newPosition: [number, number, number] = [
        char.position[0] + direction[0] * moveSpeed,
        char.position[1],
        char.position[2] + direction[2] * moveSpeed
      ];
      
      updateCharacterPosition(char.id, newPosition);
    }
  });
};

// Update character combat
const updateCombat = (deltaTime: number) => {
  const { deployedCharacters, towers, damageCharacter, damageTower, setCharacterAttacking } = useBattle.getState();
  const now = Date.now();
  
  deployedCharacters.forEach(attacker => {
    if (attacker.hp <= 0) return;
    
    // Check if enough time passed since last attack (1 attack per second)
    if (now - attacker.lastAttackTime < 1000) return;
    
    // Find target in range
    const target = findNearestTarget(attacker);
    if (!target) return;
    
    const distance = getDistance(attacker.position, target.position);
    const attackRange = getAttackRange(attacker.character.range);
    
    if (distance <= attackRange) {
      // Attack target
      setCharacterAttacking(attacker.id, true, target.id);
      
      // Deal damage after animation delay
      setTimeout(() => {
        if ('character' in target) {
          damageCharacter(target.id, attacker.character.damage);
        } else {
          damageTower(target.id, attacker.character.damage);
        }
        setCharacterAttacking(attacker.id, false);
      }, 300);
    }
  });
};

// Update tower combat
const updateTowerCombat = (deltaTime: number) => {
  const { towers, deployedCharacters, damageCharacter, setTowerAttacking } = useBattle.getState();
  const now = Date.now();
  
  towers.forEach(tower => {
    if (tower.hp <= 0) return;
    
    // Towers attack every 2 seconds
    if (now - tower.lastAttackTime < 2000) return;
    
    // Find enemy characters in range
    const enemies = deployedCharacters.filter(char => 
      char.hp > 0 && 
      char.team !== tower.type &&
      getDistance(tower.position, char.position) <= 5 // Tower range
    );
    
    if (enemies.length > 0) {
      const target = enemies[0]; // Attack first enemy in range
      const damage = tower.variant === 'main' ? 150 : 100;
      
      setTowerAttacking(tower.id, true);
      
      // Deal damage after animation delay
      setTimeout(() => {
        damageCharacter(target.id, damage);
        setTowerAttacking(tower.id, false);
      }, 500);
    }
  });
};

// Helper functions
const findNearestTarget = (character: DeployedCharacter) => {
  const { deployedCharacters, towers } = useBattle.getState();
  
  // Find enemy characters
  const enemyCharacters = deployedCharacters.filter(char => 
    char.hp > 0 && 
    char.team !== character.team
  );
  
  // Find enemy towers
  const enemyTowers = towers.filter(tower => 
    tower.hp > 0 && 
    tower.type !== character.team
  );
  
  // Combine all potential targets
  const allTargets = [
    ...enemyCharacters.map(char => ({ ...char, position: char.position })),
    ...enemyTowers.map(tower => ({ ...tower, position: tower.position }))
  ];
  
  if (allTargets.length === 0) return null;
  
  // Find nearest target
  let nearestTarget = allTargets[0];
  let nearestDistance = getDistance(character.position, nearestTarget.position);
  
  allTargets.forEach(target => {
    const distance = getDistance(character.position, target.position);
    if (distance < nearestDistance) {
      nearestDistance = distance;
      nearestTarget = target;
    }
  });
  
  return nearestTarget;
};

const getDistance = (pos1: [number, number, number], pos2: [number, number, number]): number => {
  const dx = pos1[0] - pos2[0];
  const dy = pos1[1] - pos2[1];
  const dz = pos1[2] - pos2[2];
  return Math.sqrt(dx * dx + dy * dy + dz * dz);
};

const getAttackRange = (range: 'short' | 'medium' | 'long'): number => {
  switch (range) {
    case 'short': return 1;
    case 'medium': return 3;
    case 'long': return 5;
    default: return 1;
  }
};

const normalize = (vector: [number, number, number]): [number, number, number] => {
  const length = Math.sqrt(vector[0] * vector[0] + vector[1] * vector[1] + vector[2] * vector[2]);
  if (length === 0) return [0, 0, 0];
  return [vector[0] / length, vector[1] / length, vector[2] / length];
};

// Special abilities (simplified for MVP)
export const triggerAbility = (characterId: string) => {
  const { deployedCharacters, setCharacterAttacking } = useBattle.getState();
  const character = deployedCharacters.find(c => c.id === characterId);
  
  if (!character || !character.character.ability) return;
  
  // Simple ability trigger - just visual effect for now
  setCharacterAttacking(characterId, true);
  setTimeout(() => {
    setCharacterAttacking(characterId, false);
  }, 1000);
};
