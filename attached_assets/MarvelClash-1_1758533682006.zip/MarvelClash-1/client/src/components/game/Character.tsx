import { useRef, useEffect, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { Character as CharacterType } from '../../data/characters';
import { useBattle } from '../../lib/stores/useBattle';
import { useAudio } from '../../lib/stores/useAudio';
import { VisualEffects } from './VisualEffects';
import { AttackEffects } from './AttackEffects';
import { AoEIndicator } from './AoEIndicator';

interface CharacterProps {
  character: CharacterType;
  position: [number, number, number];
  id: string;
  team: 'hero' | 'villain';
}

export default function Character({ character, position, id, team }: CharacterProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const groupRef = useRef<THREE.Group>(null);
  const headRef = useRef<THREE.Mesh>(null);
  const armLeftRef = useRef<THREE.Mesh>(null);
  const armRightRef = useRef<THREE.Mesh>(null);
  const legLeftRef = useRef<THREE.Mesh>(null);
  const legRightRef = useRef<THREE.Mesh>(null);
  
  const { deployedCharacters, updateCharacterPosition, removeCharacter } = useBattle();
  const { playHit } = useAudio();
  
  const [animationState, setAnimationState] = useState<'idle' | 'walking' | 'attacking' | 'ability' | 'dying'>('idle');
  const deathStartTime = useRef<number | null>(null);
  const particleRotation = useRef(0);
  const particleGroupRef = useRef<THREE.Group>(null);
  
  const deployedChar = deployedCharacters.find(c => c.id === id);
  const currentHP = deployedChar?.hp || character.hp;
  const maxHP = character.hp;
  const hpPercentage = currentHP / maxHP;

  // Movement and animation logic
  useFrame((state, delta) => {
    if (!groupRef.current || !deployedChar) return;

    const currentPos = groupRef.current.position;
    const time = state.clock.elapsedTime;
    const characterHash = id.length; // Unique offset for each character
    
    // Determine animation state
    let newAnimationState: typeof animationState = 'idle';
    
    if (deployedChar.hp <= 0) {
      newAnimationState = 'dying';
      if (!deathStartTime.current) {
        deathStartTime.current = time;
      }
    } else if (deployedChar.abilityActive) {
      newAnimationState = 'ability';
    } else if (deployedChar.isAttacking) {
      newAnimationState = 'attacking';
    } else {
      // Check if character is moving
      const targetZ = team === 'hero' ? -12 : 12;
      const direction = targetZ - currentPos.z;
      const moveSpeed = character.speed * delta;
      
      if (Math.abs(direction) > 0.5) {
        const moveZ = direction > 0 ? moveSpeed : -moveSpeed;
        currentPos.z += moveZ;
        updateCharacterPosition(id, [currentPos.x, currentPos.y, currentPos.z]);
        newAnimationState = 'walking';
      }
    }
    
    // Reset limb positions for state transitions
    const resetLimbPositions = () => {
      if (armLeftRef.current) {
        armLeftRef.current.rotation.set(0, 0, 0);
        armLeftRef.current.position.set(-0.4, 0.3, 0);
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.set(0, 0, 0);
        armRightRef.current.position.set(0.4, 0.3, 0);
      }
      if (legLeftRef.current) {
        legLeftRef.current.rotation.set(0, 0, 0);
        legLeftRef.current.position.set(-0.2, -0.9, 0);
      }
      if (legRightRef.current) {
        legRightRef.current.rotation.set(0, 0, 0);
        legRightRef.current.position.set(0.2, -0.9, 0);
      }
      if (meshRef.current) {
        meshRef.current.rotation.set(0, 0, 0);
        meshRef.current.scale.set(1, 1, 1);
      }
      if (headRef.current) {
        headRef.current.position.set(0, 0.9, 0);
        headRef.current.rotation.set(0, 0, 0);
      }
    };
    
    // Reset limbs and update state when changing states
    if (newAnimationState !== animationState) {
      resetLimbPositions();
      setAnimationState(newAnimationState);
    }
    
    // Update particle rotation for ability effects
    particleRotation.current += delta * 2;
    
    // Animate ability particles if active
    if (deployedChar.abilityActive && particleGroupRef.current) {
      particleGroupRef.current.rotation.y = particleRotation.current;
      
      // Animate individual particles
      particleGroupRef.current.children.forEach((child, i) => {
        if (child instanceof THREE.Mesh) {
          const baseY = 0.2;
          const bounce = Math.sin(particleRotation.current * 3 + i) * 0.2;
          child.position.y = baseY + bounce;
          
          // Slight scaling effect
          const scale = 1 + Math.sin(particleRotation.current * 2 + i) * 0.3;
          child.scale.setScalar(scale);
        }
      });
    }

    // Apply character-specific movement animations
    switch (animationState) {
      case 'walking':
        applyCharacterSpecificMovement(
          character.name, 
          character.movementType, 
          time, 
          characterHash, 
          currentPos, 
          position, 
          meshRef, 
          headRef, 
          armLeftRef, 
          armRightRef, 
          legLeftRef, 
          legRightRef
        );
        break;
        
      case 'attacking':
        // Attack animation based on character type
        const attackSpeed = 15;
        const attackTime = time * attackSpeed + characterHash;
        
        if (character.range === 'long') {
          // Ranged attack - lean forward and aim
          if (meshRef.current) {
            meshRef.current.rotation.x = Math.sin(attackTime * 2) * 0.1 - 0.1;
            meshRef.current.rotation.y = Math.sin(attackTime * 3) * 0.05;
          }
          // Arms extended for aiming
          if (armLeftRef.current) armLeftRef.current.rotation.x = -0.3;
          if (armRightRef.current) armRightRef.current.rotation.x = -0.3;
        } else {
          // Melee attack - more dramatic swinging
          if (meshRef.current) {
            meshRef.current.rotation.y = Math.sin(attackTime * 4) * 0.3;
            meshRef.current.rotation.x = Math.sin(attackTime * 2) * 0.1;
          }
          // Alternating arm swings
          if (armLeftRef.current) {
            armLeftRef.current.rotation.x = Math.sin(attackTime * 2) * 0.5;
          }
          if (armRightRef.current) {
            armRightRef.current.rotation.x = Math.sin(attackTime * 2 + Math.PI) * 0.5;
          }
        }
        break;
        
      case 'ability':
        // Special ability animation - dramatic spinning and scaling
        const abilitySpeed = 10;
        const abilityTime = time * abilitySpeed + characterHash;
        
        if (meshRef.current) {
          meshRef.current.rotation.y = abilityTime * 0.5;
          meshRef.current.scale.setScalar(1 + Math.sin(abilityTime * 3) * 0.1);
        }
        
        // Dramatic arm poses
        if (armLeftRef.current) armLeftRef.current.rotation.z = Math.PI * 0.3;
        if (armRightRef.current) armRightRef.current.rotation.z = -Math.PI * 0.3;
        
        // Floating higher during ability
        currentPos.y = position[1] + 0.2 + Math.sin(abilityTime * 2) * 0.1;
        break;
        
      case 'dying':
        // Death animation - falling and fading
        if (deathStartTime.current) {
          const deathElapsed = time - deathStartTime.current;
          const deathDuration = 1.0; // 1 second death animation
          
          if (meshRef.current) {
            meshRef.current.rotation.z = Math.min(Math.PI / 2, (deathElapsed / deathDuration) * Math.PI / 2);
            const fadeProgress = Math.min(1, deathElapsed / deathDuration);
            meshRef.current.scale.setScalar(1 - fadeProgress * 0.5); // Shrinking effect
          }
          
          // Remove character after death animation completes
          if (deathElapsed >= deathDuration) {
            removeCharacter(id);
            return;
          }
        }
        break;
        
      case 'idle':
      default:
        // Idle animation - subtle breathing and occasional movements
        const idleTime = time * 0.5 + characterHash;
        
        // Subtle breathing
        if (meshRef.current) {
          meshRef.current.scale.y = 1 + Math.sin(idleTime * 2) * 0.02;
        }
        
        // Occasional head turn
        if (headRef.current) {
          headRef.current.rotation.y = Math.sin(idleTime * 0.3) * 0.1;
        }
        
        // Slight hover
        currentPos.y = position[1] + Math.sin(idleTime * 1.5) * 0.03;
        break;
    }
  });

  // Play death sound when character dies
  useEffect(() => {
    if (deployedChar && deployedChar.hp <= 0 && !deathStartTime.current) {
      playHit();
    }
  }, [deployedChar?.hp, playHit]);

  // Character color based on team and health
  const getCharacterColor = () => {
    const baseColor = team === 'hero' ? '#4080ff' : '#ff4040';
    const healthFactor = hpPercentage;
    return new THREE.Color(baseColor).multiplyScalar(0.5 + healthFactor * 0.5);
  };

  if (!deployedChar) {
    return null;
  }

  return (
    <group ref={groupRef} position={position}>
      {/* Character body */}
      <mesh ref={meshRef} castShadow receiveShadow>
        <boxGeometry args={[0.6, 1.2, 0.6]} />
        <meshLambertMaterial color={getCharacterColor()} />
      </mesh>

      {/* Character head/identifier */}
      <mesh ref={headRef} position={[0, 0.9, 0]} castShadow>
        <sphereGeometry args={[0.25]} />
        <meshLambertMaterial color={team === 'hero' ? '#ffffff' : '#000000'} />
      </mesh>
      
      {/* Arms */}
      <mesh ref={armLeftRef} position={[-0.4, 0.3, 0]} castShadow>
        <boxGeometry args={[0.15, 0.6, 0.15]} />
        <meshLambertMaterial color={getCharacterColor()} />
      </mesh>
      <mesh ref={armRightRef} position={[0.4, 0.3, 0]} castShadow>
        <boxGeometry args={[0.15, 0.6, 0.15]} />
        <meshLambertMaterial color={getCharacterColor()} />
      </mesh>
      
      {/* Legs */}
      <mesh ref={legLeftRef} position={[-0.2, -0.9, 0]} castShadow>
        <boxGeometry args={[0.2, 0.8, 0.2]} />
        <meshLambertMaterial color={getCharacterColor()} />
      </mesh>
      <mesh ref={legRightRef} position={[0.2, -0.9, 0]} castShadow>
        <boxGeometry args={[0.2, 0.8, 0.2]} />
        <meshLambertMaterial color={getCharacterColor()} />
      </mesh>

      {/* Health bar */}
      <group position={[0, 1.5, 0]} rotation={[0, Math.PI/4, 0]}>
        <mesh>
          <planeGeometry args={[1, 0.1]} />
          <meshBasicMaterial color="#333333" />
        </mesh>
        <mesh position={[-(0.5 - hpPercentage * 0.5), 0, 0.01]}>
          <planeGeometry args={[hpPercentage, 0.08]} />
          <meshBasicMaterial color={hpPercentage > 0.5 ? '#00ff00' : hpPercentage > 0.25 ? '#ffff00' : '#ff0000'} />
        </mesh>
      </group>

      {/* Enhanced visual effects system */}
      <VisualEffects
        characterName={character.name}
        abilityActive={deployedChar.abilityActive}
        position={[0, 0, 0]}
        team={team}
      />
      
      {/* Attack effects system */}
      <AttackEffects
        characterName={character.name}
        isAttacking={deployedChar.isAttacking}
        position={[0, 0, 0]}
        team={team}
        range={character.range}
      />
      
      {/* AoE indicator system */}
      <AoEIndicator
        characterName={character.name}
        abilityActive={deployedChar.abilityActive}
        position={[0, -1, 0]}
        show={deployedChar.abilityActive || deployedChar.isAttacking}
      />
      
      {/* Basic ability indicator (fallback) */}
      {deployedChar.abilityActive && (
        <group>
          {/* Base ring effect */}
          <mesh position={[0, 0, 0]} rotation={[Math.PI/2, 0, 0]}>
            <torusGeometry args={[1.2, 0.05, 8, 32]} />
            <meshBasicMaterial color={getAbilityColor(character.name)} transparent opacity={0.4} />
          </mesh>
          {/* Particles group - animated via useFrame */}
          <group ref={particleGroupRef}>
            {Array.from({length: 8}).map((_, i) => {
              const angle = (i / 8) * Math.PI * 2;
              const radius = 1.5;
              return (
                <mesh
                  key={i}
                  position={[
                    Math.cos(angle) * radius,
                    0.2,
                    Math.sin(angle) * radius
                  ]}
                >
                  <sphereGeometry args={[0.05]} />
                  <meshBasicMaterial color={getAbilityColor(character.name)} />
                </mesh>
              );
            })}
          </group>
        </group>
      )}

      {/* Enhanced attack effects */}
      {deployedChar.isAttacking && (
        <group>
          {character.range === 'long' ? (
            // Projectile/beam effect for ranged - properly oriented
            <mesh 
              position={[0, 0.6, team === 'hero' ? -1.5 : 1.5]}
              rotation={[Math.PI / 2, 0, 0]} // Rotate to align along Z-axis
            >
              <cylinderGeometry args={[0.03, 0.03, 3]} />
              <meshBasicMaterial color={getAttackColor(character.name)} />
            </mesh>
          ) : (
            // Melee impact effect
            <>
              <mesh position={[0, 0.6, team === 'hero' ? -0.8 : 0.8]}>
                <sphereGeometry args={[0.2]} />
                <meshBasicMaterial color={getAttackColor(character.name)} transparent opacity={0.7} />
              </mesh>
              {/* Slash marks */}
              <mesh position={[0, 0.6, team === 'hero' ? -0.8 : 0.8]} rotation={[0, 0, Math.PI/4]}>
                <planeGeometry args={[0.1, 1]} />
                <meshBasicMaterial color="#ffffff" transparent opacity={0.9} />
              </mesh>
            </>
          )}
        </group>
      )}
    </group>
  );
}

// Character-specific movement animation function
function applyCharacterSpecificMovement(
  characterName: string,
  movementType: string,
  time: number, 
  characterHash: number,
  currentPos: THREE.Vector3,
  position: [number, number, number],
  meshRef: React.RefObject<THREE.Mesh>,
  headRef: React.RefObject<THREE.Mesh>,
  armLeftRef: React.RefObject<THREE.Mesh>,
  armRightRef: React.RefObject<THREE.Mesh>,
  legLeftRef: React.RefObject<THREE.Mesh>,
  legRightRef: React.RefObject<THREE.Mesh>
) {
  const walkSpeed = 8;
  const walkTime = time * walkSpeed + characterHash;

  switch (characterName) {
    case 'Iron Man':
      // Hovering with repulsors
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.5) * 0.1;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 3) * 0.02);
      }
      // Arms slightly extended for repulsors
      if (armLeftRef.current) armLeftRef.current.rotation.z = -0.3;
      if (armRightRef.current) armRightRef.current.rotation.z = 0.3;
      // Hovering motion
      currentPos.y = position[1] + 0.3 + Math.sin(walkTime * 2) * 0.1;
      break;

    case 'Thor':
      // Lightning steps with electrical energy
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 4) * 0.05;
        // Lightning flash effect
        if (Math.sin(walkTime * 8) > 0.8) {
          meshRef.current.scale.setScalar(1.1);
        } else {
          meshRef.current.scale.setScalar(1);
        }
      }
      // Mjolnir wielding pose
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime) * 0.2 - 0.2;
        armRightRef.current.rotation.z = 0.4;
      }
      // Heavy steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.3;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.3;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 4)) * 0.08;
      break;

    case 'Hulk':
      // Ground-shaking heavy movement
      if (meshRef.current) {
        meshRef.current.rotation.z = Math.sin(walkTime) * 0.1;
        meshRef.current.scale.setScalar(1 + Math.abs(Math.sin(walkTime * 2)) * 0.05);
      }
      // Heavy arm swings
      if (armLeftRef.current) armLeftRef.current.rotation.x = Math.sin(walkTime) * 0.4;
      if (armRightRef.current) armRightRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.4;
      // Massive leg stomps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.4;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.4;
      // Ground shake effect
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 4)) * 0.12;
      break;

    case 'Spider-Man':
      // Web-swinging motion
      if (meshRef.current) {
        meshRef.current.rotation.z = Math.sin(walkTime * 1.5) * 0.2;
        meshRef.current.rotation.y = Math.sin(walkTime * 0.8) * 0.1;
      }
      // Web-shooting poses
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2) * 0.3 - 0.2;
        armLeftRef.current.rotation.z = Math.sin(walkTime) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.3 - 0.2;
        armRightRef.current.rotation.z = Math.sin(walkTime + Math.PI) * 0.2;
      }
      // Agile leg movements
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 3 + Math.PI) * 0.25;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 3) * 0.25;
      // Swinging arc motion
      currentPos.y = position[1] + Math.sin(walkTime * 1.5) * 0.15;
      break;

    case 'Doctor Strange':
      // Mystical floating with cape motion
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.3;
        meshRef.current.scale.y = 1 + Math.sin(walkTime * 2) * 0.03;
      }
      // Mystical hand gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 1.5) * 0.3;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 2) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 1.5 + Math.PI) * 0.3;
        armRightRef.current.rotation.y = Math.sin(walkTime * 2 + Math.PI) * 0.2;
      }
      // Mystical floating
      currentPos.y = position[1] + 0.2 + Math.sin(walkTime * 1.2) * 0.08;
      break;

    case 'Captain Marvel':
      // Cosmic energy flight
      if (meshRef.current) {
        meshRef.current.rotation.x = -0.1; // Slight forward lean
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 4) * 0.02);
      }
      // Arms back for flight
      if (armLeftRef.current) armLeftRef.current.rotation.x = 0.3;
      if (armRightRef.current) armRightRef.current.rotation.x = 0.3;
      // Cosmic flight
      currentPos.y = position[1] + 0.4 + Math.sin(walkTime * 2.5) * 0.06;
      break;

    case 'Falcon':
      // Wing-flapping flight simulation
      if (meshRef.current) {
        meshRef.current.rotation.x = -0.05;
      }
      // Wing flapping motion
      if (armLeftRef.current) {
        armLeftRef.current.rotation.z = Math.sin(walkTime * 6) * 0.6 - 0.3;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 6) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.z = Math.sin(walkTime * 6) * 0.6 + 0.3;
        armRightRef.current.rotation.y = Math.sin(walkTime * 6) * -0.2;
      }
      // Flight motion
      currentPos.y = position[1] + 0.5 + Math.sin(walkTime * 3) * 0.1;
      break;

    case 'Ant-Man':
      // Size-changing effects during movement
      const sizeVariation = 1 + Math.sin(walkTime * 5) * 0.15;
      if (meshRef.current) {
        meshRef.current.scale.setScalar(sizeVariation);
        meshRef.current.rotation.y = Math.sin(walkTime * 2) * 0.05;
      }
      // Normal walking with size effects
      if (armLeftRef.current) armLeftRef.current.rotation.x = Math.sin(walkTime) * 0.3;
      if (armRightRef.current) armRightRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.3;
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.2;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.2;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 2)) * 0.05 * sizeVariation;
      break;

    case 'Thanos':
      // Menacing, powerful stride
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.8) * 0.03;
        meshRef.current.scale.setScalar(1 + Math.abs(Math.sin(walkTime)) * 0.02);
      }
      // Gauntlet pose
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 0.8) * 0.2;
        armLeftRef.current.rotation.z = -0.1;
      }
      if (armRightRef.current) armRightRef.current.rotation.x = Math.sin(walkTime * 0.8 + Math.PI) * 0.2;
      // Heavy, slow steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 0.8 + Math.PI) * 0.25;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 0.8) * 0.25;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 1.6)) * 0.06;
      break;

    case 'Ultron':
      // Mechanical hovering with robotic precision
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 3) * 0.02;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 8) * 0.01);
      }
      // Robotic arm movements
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 4) * 0.1;
        armLeftRef.current.rotation.z = -0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 4 + Math.PI) * 0.1;
        armRightRef.current.rotation.z = 0.2;
      }
      // Mechanical hovering
      currentPos.y = position[1] + 0.2 + Math.sin(walkTime * 4) * 0.03;
      break;

    case 'Venom':
      // Symbiote crawling/flowing motion
      if (meshRef.current) {
        meshRef.current.rotation.z = Math.sin(walkTime * 3) * 0.15;
        meshRef.current.scale.y = 1 + Math.sin(walkTime * 4) * 0.08;
      }
      // Tendril-like arm movements
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2.5) * 0.4;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 1.8) * 0.3;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2.5 + Math.PI) * 0.4;
        armRightRef.current.rotation.z = Math.sin(walkTime * 1.8 + Math.PI) * 0.3;
      }
      // Flowing leg movements
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.3;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 2) * 0.3;
      currentPos.y = position[1] + Math.sin(walkTime * 3) * 0.08;
      break;

    case 'Loki':
      // Graceful, deceptive movement
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 1.5) * 0.08;
        meshRef.current.rotation.z = Math.sin(walkTime * 2) * 0.03;
      }
      // Elegant gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 1.2) * 0.2;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 0.8) * 0.15;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 1.2 + Math.PI) * 0.2;
        armRightRef.current.rotation.y = Math.sin(walkTime * 0.8 + Math.PI) * 0.15;
      }
      // Smooth steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.15;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.15;
      currentPos.y = position[1] + Math.sin(walkTime * 1.5) * 0.04;
      break;

    case 'Green Goblin':
      // Glider-like hovering motion
      if (meshRef.current) {
        meshRef.current.rotation.x = Math.sin(walkTime * 2) * 0.1 - 0.05;
        meshRef.current.rotation.z = Math.sin(walkTime * 1.5) * 0.08;
      }
      // Maniacal arm gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 3) * 0.3;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 2) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 3 + Math.PI) * 0.3;
        armRightRef.current.rotation.y = Math.sin(walkTime * 2 + Math.PI) * 0.2;
      }
      // Glider flight
      currentPos.y = position[1] + 0.3 + Math.sin(walkTime * 2) * 0.12;
      break;

    case 'Magneto':
      // Magnetic levitation
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.2;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 2) * 0.02);
      }
      // Magnetic field gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 1.5) * 0.2 - 0.3;
        armLeftRef.current.rotation.z = -0.3;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 1.5 + Math.PI) * 0.2 - 0.3;
        armRightRef.current.rotation.z = 0.3;
      }
      // Magnetic levitation
      currentPos.y = position[1] + 0.4 + Math.sin(walkTime * 1.2) * 0.05;
      break;

    case 'Captain America':
      // Shield bearer stance and determined march
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.5) * 0.02;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 2) * 0.01);
      }
      // Shield holding pose
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = -0.2;
        armLeftRef.current.rotation.z = -0.3;
      }
      if (armRightRef.current) armRightRef.current.rotation.x = Math.sin(walkTime) * 0.25;
      // Determined steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.25;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.25;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 2)) * 0.04;
      break;

    case 'Black Widow':
      // Stealthy, agile movements
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 3) * 0.08;
        meshRef.current.rotation.z = Math.sin(walkTime * 2) * 0.05;
      }
      // Combat ready poses
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2.5) * 0.2 - 0.1;
        armLeftRef.current.rotation.z = Math.sin(walkTime) * 0.1;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2.5 + Math.PI) * 0.2 - 0.1;
        armRightRef.current.rotation.z = Math.sin(walkTime + Math.PI) * 0.1;
      }
      // Stealthy steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.15;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 2) * 0.15;
      currentPos.y = position[1] + Math.sin(walkTime * 2.5) * 0.03;
      break;

    case 'Hawkeye':
      // Archer stance with bow ready
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.8) * 0.05;
      }
      // Bow drawing pose
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = -0.4;
        armLeftRef.current.rotation.z = -0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = -0.3;
        armRightRef.current.rotation.z = 0.4;
      }
      // Steady archer steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.2;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.2;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 1.5)) * 0.04;
      break;

    case 'Black Panther':
      // Predatory, stealthy movement
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 2) * 0.1;
        meshRef.current.rotation.z = Math.sin(walkTime * 1.5) * 0.08;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 3) * 0.02);
      }
      // Clawed stance
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2) * 0.3;
        armLeftRef.current.rotation.z = Math.sin(walkTime) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.3;
        armRightRef.current.rotation.z = Math.sin(walkTime + Math.PI) * 0.2;
      }
      // Cat-like prowling
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 2.5 + Math.PI) * 0.25;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 2.5) * 0.25;
      currentPos.y = position[1] + Math.sin(walkTime * 2) * 0.06;
      break;

    case 'Scarlet Witch':
      // Reality-warping magical floating
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.4;
        meshRef.current.scale.y = 1 + Math.sin(walkTime * 3) * 0.04;
      }
      // Magical gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2) * 0.4;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 1.5) * 0.3;
        armLeftRef.current.rotation.z = Math.sin(walkTime) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.4;
        armRightRef.current.rotation.y = Math.sin(walkTime * 1.5 + Math.PI) * 0.3;
        armRightRef.current.rotation.z = Math.sin(walkTime + Math.PI) * 0.2;
      }
      // Reality-bending float
      currentPos.y = position[1] + 0.25 + Math.sin(walkTime * 1.8) * 0.12;
      break;

    case 'Vision':
      // Phasing density manipulation
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.1;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 4) * 0.03);
        // Phasing opacity effect simulation via scale variation
      }
      // Calculating android gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 1.2) * 0.15;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 0.8) * 0.1;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 1.2 + Math.PI) * 0.15;
        armRightRef.current.rotation.y = Math.sin(walkTime * 0.8 + Math.PI) * 0.1;
      }
      // Precise floating
      currentPos.y = position[1] + 0.15 + Math.sin(walkTime * 1.5) * 0.05;
      break;

    case 'Winter Soldier':
      // Mechanical arm with military precision
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.5) * 0.02;
      }
      // Mechanical arm movement
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 3) * 0.2;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 2) * 0.1;
      }
      // Normal arm
      if (armRightRef.current) armRightRef.current.rotation.x = Math.sin(walkTime) * 0.25;
      // Military march
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.25;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.25;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 2)) * 0.04;
      break;

    case 'Red Skull':
      // Menacing, authoritative stride
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.6) * 0.04;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime) * 0.015);
      }
      // Commanding gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 0.8) * 0.2;
        armLeftRef.current.rotation.z = -0.1;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 0.8 + Math.PI) * 0.2;
        armRightRef.current.rotation.z = 0.1;
      }
      // Authoritative steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.2;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.2;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 1.2)) * 0.05;
      break;

    case 'Hela':
      // Dark goddess floating with necromantic energy
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.3;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 2.5) * 0.03);
      }
      // Death magic gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 1.8) * 0.3;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 1.2) * 0.2;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 0.8) * 0.15;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 1.8 + Math.PI) * 0.3;
        armRightRef.current.rotation.y = Math.sin(walkTime * 1.2 + Math.PI) * 0.2;
        armRightRef.current.rotation.z = Math.sin(walkTime * 0.8 + Math.PI) * 0.15;
      }
      // Dark energy float
      currentPos.y = position[1] + 0.3 + Math.sin(walkTime * 1.5) * 0.1;
      break;

    case 'Dormammu':
      // Dark dimension energy manifestation
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.5;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 3) * 0.05);
        meshRef.current.rotation.z = Math.sin(walkTime * 2) * 0.08;
      }
      // Dimensional magic
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2.2) * 0.4;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 1.8) * 0.3;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 1.2) * 0.25;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2.2 + Math.PI) * 0.4;
        armRightRef.current.rotation.y = Math.sin(walkTime * 1.8 + Math.PI) * 0.3;
        armRightRef.current.rotation.z = Math.sin(walkTime * 1.2 + Math.PI) * 0.25;
      }
      // Dark dimension floating
      currentPos.y = position[1] + 0.4 + Math.sin(walkTime * 1.3) * 0.15;
      break;

    case 'Mysterio':
      // Illusion smoke and floating
      if (meshRef.current) {
        meshRef.current.rotation.y = time * 0.6;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 4) * 0.04);
        meshRef.current.rotation.x = Math.sin(walkTime * 2) * 0.05;
      }
      // Illusion casting gestures
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 3) * 0.35;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 2.5) * 0.25;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 1.5) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 3 + Math.PI) * 0.35;
        armRightRef.current.rotation.y = Math.sin(walkTime * 2.5 + Math.PI) * 0.25;
        armRightRef.current.rotation.z = Math.sin(walkTime * 1.5 + Math.PI) * 0.2;
      }
      // Smoke-like floating
      currentPos.y = position[1] + 0.25 + Math.sin(walkTime * 2.2) * 0.1;
      break;

    case 'Kingpin':
      // Heavy, intimidating presence
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.4) * 0.02;
        meshRef.current.scale.setScalar(1 + Math.abs(Math.sin(walkTime * 0.8)) * 0.02);
      }
      // Powerful arm movements
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 0.6) * 0.15;
        armLeftRef.current.rotation.z = -0.05;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 0.6 + Math.PI) * 0.15;
        armRightRef.current.rotation.z = 0.05;
      }
      // Heavy steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 0.8 + Math.PI) * 0.2;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 0.8) * 0.2;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 1.6)) * 0.04;
      break;

    case 'Killmonger':
      // Aggressive, tactical movements
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 1.5) * 0.06;
        meshRef.current.rotation.z = Math.sin(walkTime * 2) * 0.04;
      }
      // Combat ready stance
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2.2) * 0.25;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 1.8) * 0.15;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2.2 + Math.PI) * 0.25;
        armRightRef.current.rotation.z = Math.sin(walkTime * 1.8 + Math.PI) * 0.15;
      }
      // Aggressive steps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.25;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 2) * 0.25;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 2.5)) * 0.05;
      break;

    case 'Ronan':
      // Accuser staff wielding authority
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.5) * 0.03;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 1.5) * 0.02);
      }
      // Staff wielding pose
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = -0.3;
        armLeftRef.current.rotation.z = -0.1;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = -0.2;
        armRightRef.current.rotation.z = 0.2;
      }
      // Authoritative march
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.2;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.2;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 1.2)) * 0.04;
      break;

    case 'Yellowjacket':
      // Insect-like hovering with wings
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 4) * 0.08;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 8) * 0.03);
      }
      // Wing-like arm movements
      if (armLeftRef.current) {
        armLeftRef.current.rotation.z = Math.sin(walkTime * 8) * 0.4 - 0.2;
        armLeftRef.current.rotation.x = Math.sin(walkTime * 6) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.z = Math.sin(walkTime * 8) * 0.4 + 0.2;
        armRightRef.current.rotation.x = Math.sin(walkTime * 6) * 0.2;
      }
      // Insect hovering
      currentPos.y = position[1] + 0.4 + Math.sin(walkTime * 4) * 0.08;
      break;

    case 'Abomination':
      // Monstrous, heavy movement
      if (meshRef.current) {
        meshRef.current.rotation.z = Math.sin(walkTime * 0.8) * 0.12;
        meshRef.current.scale.setScalar(1 + Math.abs(Math.sin(walkTime * 1.5)) * 0.06);
      }
      // Massive arm swings
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 0.9) * 0.5;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 0.7) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 0.9 + Math.PI) * 0.5;
        armRightRef.current.rotation.z = Math.sin(walkTime * 0.7 + Math.PI) * 0.2;
      }
      // Monstrous stomps
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 0.8 + Math.PI) * 0.4;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 0.8) * 0.4;
      // Heavy ground impact
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 1.6)) * 0.1;
      break;

    default:
      // Movement type-based fallback for any remaining characters
      applyMovementTypeAnimation(movementType, walkTime, currentPos, position, meshRef, headRef, armLeftRef, armRightRef, legLeftRef, legRightRef);
      break;
  }
}

// Movement type-based animation fallback for characters without specific animations
function applyMovementTypeAnimation(
  movementType: string,
  walkTime: number,
  currentPos: THREE.Vector3,
  position: [number, number, number],
  meshRef: React.RefObject<THREE.Mesh>,
  headRef: React.RefObject<THREE.Mesh>,
  armLeftRef: React.RefObject<THREE.Mesh>,
  armRightRef: React.RefObject<THREE.Mesh>,
  legLeftRef: React.RefObject<THREE.Mesh>,
  legRightRef: React.RefObject<THREE.Mesh>
) {
  switch (movementType) {
    case 'hover':
    case 'float':
      // Hovering/floating motion
      if (meshRef.current) {
        meshRef.current.rotation.y = Math.sin(walkTime * 0.8) * 0.05;
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 3) * 0.02);
      }
      if (armLeftRef.current) armLeftRef.current.rotation.z = -0.2;
      if (armRightRef.current) armRightRef.current.rotation.z = 0.2;
      currentPos.y = position[1] + 0.3 + Math.sin(walkTime * 2) * 0.08;
      break;

    case 'fly':
      // Flying motion with forward lean
      if (meshRef.current) {
        meshRef.current.rotation.x = -0.1;
        meshRef.current.rotation.y = Math.sin(walkTime * 1.2) * 0.03;
      }
      if (armLeftRef.current) armLeftRef.current.rotation.x = 0.2;
      if (armRightRef.current) armRightRef.current.rotation.x = 0.2;
      currentPos.y = position[1] + 0.4 + Math.sin(walkTime * 2.5) * 0.1;
      break;

    case 'glide':
      // Gliding motion
      if (meshRef.current) {
        meshRef.current.rotation.x = Math.sin(walkTime * 1.5) * 0.08;
        meshRef.current.rotation.z = Math.sin(walkTime * 1.8) * 0.05;
      }
      if (armLeftRef.current) armLeftRef.current.rotation.z = -0.4;
      if (armRightRef.current) armRightRef.current.rotation.z = 0.4;
      currentPos.y = position[1] + 0.25 + Math.sin(walkTime * 1.8) * 0.12;
      break;

    case 'crawl':
      // Crawling motion (lower to ground)
      if (meshRef.current) {
        meshRef.current.rotation.z = Math.sin(walkTime * 2.5) * 0.1;
        meshRef.current.scale.y = 0.8 + Math.sin(walkTime * 3) * 0.1;
      }
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 2) * 0.4;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 1.5) * 0.2;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 2 + Math.PI) * 0.4;
        armRightRef.current.rotation.z = Math.sin(walkTime * 1.5 + Math.PI) * 0.2;
      }
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime * 2.5 + Math.PI) * 0.3;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime * 2.5) * 0.3;
      currentPos.y = position[1] - 0.1 + Math.sin(walkTime * 2.5) * 0.08;
      break;

    case 'teleport':
      // Teleporting with blinking effect
      if (meshRef.current) {
        const blinkFreq = Math.sin(walkTime * 8);
        meshRef.current.scale.setScalar(blinkFreq > 0.7 ? 1.1 : 0.9);
        meshRef.current.rotation.y = walkTime * 0.3;
      }
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 4) * 0.2;
        armLeftRef.current.rotation.y = Math.sin(walkTime * 3) * 0.15;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 4 + Math.PI) * 0.2;
        armRightRef.current.rotation.y = Math.sin(walkTime * 3 + Math.PI) * 0.15;
      }
      currentPos.y = position[1] + Math.sin(walkTime * 6) * 0.1;
      break;

    case 'phase':
      // Phasing with opacity-like scale effects
      if (meshRef.current) {
        meshRef.current.scale.setScalar(1 + Math.sin(walkTime * 4) * 0.05);
        meshRef.current.rotation.y = Math.sin(walkTime * 0.5) * 0.08;
      }
      if (armLeftRef.current) {
        armLeftRef.current.rotation.x = Math.sin(walkTime * 1.5) * 0.2;
        armLeftRef.current.rotation.z = Math.sin(walkTime * 2) * 0.1;
      }
      if (armRightRef.current) {
        armRightRef.current.rotation.x = Math.sin(walkTime * 1.5 + Math.PI) * 0.2;
        armRightRef.current.rotation.z = Math.sin(walkTime * 2 + Math.PI) * 0.1;
      }
      currentPos.y = position[1] + Math.sin(walkTime * 2.5) * 0.06;
      break;

    case 'walk':
    default:
      // Default walking animation
      if (meshRef.current) {
        meshRef.current.rotation.z = Math.sin(walkTime * 2) * 0.05;
        meshRef.current.rotation.y = Math.sin(walkTime) * 0.02;
      }
      if (headRef.current) {
        headRef.current.position.y = 0.9 + Math.sin(walkTime * 2) * 0.05;
      }
      if (armLeftRef.current) armLeftRef.current.rotation.x = Math.sin(walkTime) * 0.3;
      if (armRightRef.current) armRightRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.3;
      if (legLeftRef.current) legLeftRef.current.rotation.x = Math.sin(walkTime + Math.PI) * 0.2;
      if (legRightRef.current) legRightRef.current.rotation.x = Math.sin(walkTime) * 0.2;
      currentPos.y = position[1] + Math.abs(Math.sin(walkTime * 2)) * 0.05;
      break;
  }
}

// Helper functions for animation colors
function getAbilityColor(characterName: string): string {
  const colorMap: Record<string, string> = {
    'Iron Man': '#FFD700',
    'Thor': '#87CEEB',
    'Hulk': '#32CD32',
    'Doctor Strange': '#9932CC',
    'Scarlet Witch': '#DC143C',
    'Captain Marvel': '#FFD700',
    'Vision': '#FFD700',
    'Ant-Man': '#FF0000',
    'Falcon': '#4169E1',
    'Winter Soldier': '#708090',
    'Black Panther': '#9400D3',
    'Captain America': '#4169E1',
    'Black Widow': '#8A2BE2',
    'Hawkeye': '#32CD32',
    'Spider-Man': '#FF0000',
    'Thanos': '#800080',
    'Loki': '#228B22',
    'Dormammu': '#FF4500',
    'Magneto': '#4B0082',
    'Hela': '#000000',
    'Ultron': '#FF0000',
    'Red Skull': '#DC143C',
    'Venom': '#000000',
    'Green Goblin': '#228B22',
    'Mysterio': '#9932CC',
    'Kingpin': '#FFFFFF',
    'Killmonger': '#FFD700',
    'Ronan': '#4B0082',
    'Yellowjacket': '#FFFF00'
  };
  return colorMap[characterName] || '#FFD700';
}

function getAttackColor(characterName: string): string {
  const colorMap: Record<string, string> = {
    'Iron Man': '#FF6347',
    'Thor': '#1E90FF',
    'Hulk': '#00FF00',
    'Captain America': '#4169E1',
    'Black Widow': '#8A2BE2',
    'Hawkeye': '#32CD32',
    'Spider-Man': '#FF0000',
    'Thanos': '#800080',
    'Ultron': '#FF0000',
    'Green Goblin': '#228B22',
    'Venom': '#000000'
  };
  return colorMap[characterName] || '#FFFF00';
}
