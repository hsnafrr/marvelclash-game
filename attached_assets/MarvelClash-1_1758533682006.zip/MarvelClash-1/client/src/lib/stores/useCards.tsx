import { create } from 'zustand';
import { heroes, villains, Character } from '../../data/characters';

interface CardsState {
  heroes: Character[];
  villains: Character[];
  
  // Getters
  getAllCards: () => Character[];
  getCardById: (id: string) => Character | undefined;
  getCardsByFaction: (faction: 'hero' | 'villain') => Character[];
}

export const useCards = create<CardsState>((set, get) => ({
  heroes,
  villains,
  
  getAllCards: () => {
    const state = get();
    return [...state.heroes, ...state.villains];
  },
  
  getCardById: (id: string) => {
    const state = get();
    return state.getAllCards().find(card => card.id === id);
  },
  
  getCardsByFaction: (faction: 'hero' | 'villain') => {
    const state = get();
    return faction === 'hero' ? state.heroes : state.villains;
  }
}));
