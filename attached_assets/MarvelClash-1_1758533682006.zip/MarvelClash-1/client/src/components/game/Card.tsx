import { useDrag } from 'react-use-gesture';
import { Character } from '../../data/characters';
import { useBattle } from '../../lib/stores/useBattle';
import { useState, useRef } from 'react';

interface CardProps {
  character: Character;
  isActive: boolean;
  canAfford: boolean;
  onDeploy: (character: Character, position: [number, number, number]) => void;
}

export default function Card({ character, isActive, canAfford, onDeploy }: CardProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [dragPosition, setDragPosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);
  const { currentEnergy } = useBattle();

  const bind = useDrag(({ active, movement: [mx, my], first, last }) => {
    if (!canAfford || !isActive) return;
    
    if (first) {
      setIsDragging(true);
    }
    
    if (active) {
      setDragPosition({ x: mx, y: my });
    }
    
    if (last) {
      setIsDragging(false);
      setDragPosition({ x: 0, y: 0 });
      
      // Check if dropped in valid deployment area (bottom half of screen)
      if (my < -100) {
        // Calculate deployment position based on drop location
        const normalizedX = mx / window.innerWidth * 20 - 10; // Convert to 3D coordinates
        const deployPosition: [number, number, number] = [
          Math.max(-8, Math.min(8, normalizedX)), // Clamp to arena bounds
          0,
          8 // Deploy in player's area
        ];
        onDeploy(character, deployPosition);
      }
    }
  });

  const cardStyle = {
    transform: `translate3d(${dragPosition.x}px, ${dragPosition.y}px, 0) scale(${
      isDragging ? 1.05 : isHovered ? 1.1 : 1
    })`,
    opacity: isDragging ? 0.9 : 1,
    cursor: canAfford && isActive ? 'grab' : 'not-allowed'
  };

  const getMarvelFrame = () => {
    if (character.faction === 'hero') {
      // Heroes: Blue and gold holographic frame
      return {
        outer: 'from-blue-600 via-blue-500 to-cyan-400',
        inner: 'from-yellow-400 via-amber-300 to-yellow-500',
        border: 'border-blue-400',
        glow: 'shadow-blue-500/50',
        accent: '#fbbf24'
      };
    } else {
      // Villains: Red and purple holographic frame
      return {
        outer: 'from-red-600 via-red-500 to-pink-400', 
        inner: 'from-purple-500 via-violet-400 to-purple-600',
        border: 'border-red-400',
        glow: 'shadow-red-500/50',
        accent: '#a855f7'
      };
    }
  };

  const getRarityGlow = () => {
    if (character.cost >= 7) return 'shadow-2xl shadow-yellow-400/60'; // Legendary
    if (character.cost >= 5) return 'shadow-xl shadow-purple-400/50'; // Epic  
    if (character.cost >= 3) return 'shadow-lg shadow-blue-400/40'; // Rare
    return 'shadow-md shadow-gray-400/30'; // Common
  };

  const getStatIcon = (stat: string) => {
    switch (stat) {
      case 'hp': return '❤️';
      case 'damage': return '⚔️';
      case 'speed': return '💨';
      case 'range': return '🎯';
      default: return '📊';
    }
  };

  const getRangeDisplay = (range: string) => {
    switch (range) {
      case 'short': return 'S';
      case 'medium': return 'M';
      case 'long': return 'L';
      default: return '?';
    }
  };

  const marvelFrame = getMarvelFrame();

  return (
    <div
      ref={cardRef}
      {...bind()}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={`
        relative w-24 h-36 mx-1 rounded-xl border-2 ${marvelFrame.border}
        bg-gradient-to-br ${marvelFrame.outer}
        ${!canAfford || !isActive ? 'opacity-60 grayscale' : ''}
        ${isDragging ? 'z-50' : 'z-10'}
        ${getRarityGlow()}
        ${isHovered ? marvelFrame.glow : ''}
        transition-all duration-300 ease-out
        overflow-hidden group
      `}
      style={cardStyle}
    >
      {/* Holographic effect overlay */}
      <div className={`absolute inset-0 bg-gradient-to-tr ${marvelFrame.inner} opacity-30 
        ${isHovered ? 'animate-pulse' : ''} transition-all duration-300`} />
      
      {/* Holographic shine effect */}
      <div className={`absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-20
        transform ${isHovered ? 'translate-x-full' : '-translate-x-full'} 
        transition-transform duration-700 ease-in-out skew-x-12`} />

      {/* Energy cost infinity stone */}
      <div className="absolute -top-2 -left-2 w-7 h-7 rounded-full flex items-center justify-center text-white text-xs font-bold border-2 border-white shadow-lg"
           style={{ backgroundColor: marvelFrame.accent }}>
        {character.cost}
      </div>

      {/* Character portrait */}
      <div className="w-full h-20 bg-black bg-opacity-40 rounded-t-xl flex items-center justify-center relative overflow-hidden">
        {/* Character image placeholder (using initials for now) */}
        <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-white via-gray-100 to-gray-200 
                        flex items-center justify-center border-2 border-gray-300 shadow-lg">
          <span className="text-lg font-bold text-gray-800">
            {character.name.split(' ').map(word => word[0]).join('').slice(0, 2)}
          </span>
        </div>
        
        {/* Character faction indicator */}
        <div className="absolute top-1 right-1 text-lg">
          {character.faction === 'hero' ? '🦸' : '🦹'}
        </div>
      </div>

      {/* Character name */}
      <div className="px-2 py-1">
        <div className="text-xs font-bold text-white text-center truncate bg-black bg-opacity-50 rounded px-1">
          {character.name}
        </div>
      </div>

      {/* Stats section */}
      <div className="px-2 pb-2 space-y-1">
        {/* Primary stats */}
        <div className="flex justify-between text-xs text-white">
          <div className="flex items-center gap-1 bg-red-600 bg-opacity-80 px-1 rounded">
            <span>❤️</span>
            <span className="font-bold">{character.hp}</span>
          </div>
          <div className="flex items-center gap-1 bg-orange-600 bg-opacity-80 px-1 rounded">
            <span>⚔️</span>
            <span className="font-bold">{character.damage}</span>
          </div>
        </div>
        
        {/* Secondary stats */}
        <div className="flex justify-between text-xs text-white">
          <div className="flex items-center gap-1 bg-blue-600 bg-opacity-80 px-1 rounded">
            <span>💨</span>
            <span className="font-bold">{character.speed.toFixed(1)}</span>
          </div>
          <div className="flex items-center gap-1 bg-green-600 bg-opacity-80 px-1 rounded">
            <span>🎯</span>
            <span className="font-bold">{getRangeDisplay(character.range)}</span>
          </div>
        </div>
      </div>

      {/* Special ability indicator */}
      {character.ability && (
        <div className="absolute bottom-1 right-1 w-4 h-4 rounded-full flex items-center justify-center shadow-md"
             style={{ backgroundColor: marvelFrame.accent }}>
          <span className="text-xs text-white">✦</span>
        </div>
      )}

      {/* Movement type indicator */}
      <div className="absolute top-1 left-1 text-xs bg-black bg-opacity-70 text-white px-1 rounded">
        {character.movementType.charAt(0).toUpperCase()}
      </div>

      {/* Glow effect when hovered */}
      {isHovered && (
        <div className="absolute -inset-1 rounded-xl opacity-75 blur-sm -z-10"
             style={{ backgroundColor: marvelFrame.accent }} />
      )}

      {/* Deployment area indicator when dragging */}
      {isDragging && (
        <div className="fixed inset-0 pointer-events-none z-40">
          <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-blue-500 bg-opacity-20 border-t-4 border-blue-400 border-dashed" />
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-white text-xl font-bold 
                          bg-black bg-opacity-70 px-4 py-2 rounded-lg shadow-lg">
            🎯 Drop to Deploy 🎯
          </div>
        </div>
      )}
    </div>
  );
}
