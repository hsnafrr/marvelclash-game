import { useEffect } from 'react';
import { useBattle } from '../../lib/stores/useBattle';
import { useDeck } from '../../lib/stores/useDeck';
import EnergyBar from './EnergyBar';
import Card from './Card';
import { deployCharacter } from '../../lib/gameLogic';
import { Character } from '../../data/characters';
import { notifyPlayerAction } from '../../lib/ai';

export default function BattleUI() {
  const { 
    currentEnergy, 
    timeRemaining, 
    towers, 
    isOvertime,
    deployCharacter: deployInBattle 
  } = useBattle();
  const { activeCards, useCard } = useDeck();

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCardDeploy = (character: Character, position: [number, number, number]) => {
    if (currentEnergy >= character.cost) {
      deployCharacter(character, position, 'hero');
      useCard(character.id);
      notifyPlayerAction(); // Notify AI of player action for adaptive behavior
    }
  };

  const heroTower = towers.find(t => t.type === 'hero' && t.variant === 'main');
  const villainTower = towers.find(t => t.type === 'villain' && t.variant === 'main');

  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Top UI */}
      <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-auto">
        {/* Enemy tower health */}
        <div className="bg-black bg-opacity-60 px-3 py-2 rounded-lg">
          <div className="text-red-400 text-sm font-bold">Enemy Tower</div>
          <div className="w-32 h-2 bg-gray-700 rounded mt-1">
            <div 
              className="h-full bg-red-500 rounded transition-all duration-300"
              style={{ width: `${villainTower ? (villainTower.hp / 4000) * 100 : 0}%` }}
            />
          </div>
          <div className="text-white text-xs mt-1">
            {villainTower?.hp || 0}/4000
          </div>
        </div>

        {/* Timer */}
        <div className={`px-4 py-2 rounded-lg font-bold text-lg ${
          isOvertime 
            ? 'bg-orange-500 text-white animate-pulse' 
            : timeRemaining <= 30 
              ? 'bg-red-500 text-white' 
              : 'bg-black bg-opacity-60 text-white'
        }`}>
          {formatTime(timeRemaining)}
        </div>

        {/* Player tower health */}
        <div className="bg-black bg-opacity-60 px-3 py-2 rounded-lg">
          <div className="text-blue-400 text-sm font-bold">Your Tower</div>
          <div className="w-32 h-2 bg-gray-700 rounded mt-1">
            <div 
              className="h-full bg-blue-500 rounded transition-all duration-300"
              style={{ width: `${heroTower ? (heroTower.hp / 4000) * 100 : 0}%` }}
            />
          </div>
          <div className="text-white text-xs mt-1">
            {heroTower?.hp || 0}/4000
          </div>
        </div>
      </div>

      {/* Bottom UI - Cards and Energy */}
      <div className="absolute bottom-4 left-4 right-4 pointer-events-auto">
        <div className="flex flex-col items-center gap-3">
          {/* Energy bar */}
          <EnergyBar />
          
          {/* Active cards */}
          <div className="flex justify-center gap-2 bg-black bg-opacity-60 p-3 rounded-lg">
            {activeCards.map((character, index) => (
              <Card
                key={`${character.id}-${index}`}
                character={character}
                isActive={true}
                canAfford={currentEnergy >= character.cost}
                onDeploy={handleCardDeploy}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Lane indicators */}
      <div className="absolute inset-0">
        <div className="relative w-full h-full">
          {/* Left lane */}
          <div className="absolute left-8 top-1/2 bottom-8 w-px bg-yellow-400 opacity-30" />
          {/* Center lane */}
          <div className="absolute left-1/2 top-1/2 bottom-8 w-px bg-yellow-400 opacity-30" />
          {/* Right lane */}
          <div className="absolute right-8 top-1/2 bottom-8 w-px bg-yellow-400 opacity-30" />
          
          {/* Deployment zone indicator */}
          <div className="absolute bottom-0 left-0 right-0 h-1/2 border-t-2 border-green-500 border-dashed opacity-30" />
        </div>
      </div>
    </div>
  );
}
