import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useBattle } from '../../lib/stores/useBattle';

interface TowerProps {
  type: 'hero' | 'villain';
  variant: 'main' | 'side';
  position: [number, number, number];
  id: string;
}

export default function Tower({ type, variant, position, id }: TowerProps) {
  const meshRef = useRef<THREE.Mesh>(null);
  const laserOuterRef = useRef<THREE.Mesh>(null);
  const laserInnerRef = useRef<THREE.Mesh>(null);
  const { towers, deployedCharacters } = useBattle();
  
  // Use refs instead of state for 60fps updates
  const targetPositionRef = useRef<[number, number, number] | null>(null);
  const laserProgressRef = useRef(0);
  const [isTargeting, setIsTargeting] = useState(false);
  
  const tower = towers.find(t => t.id === id);
  const maxHP = variant === 'main' ? 4000 : 2000;
  const currentHP = tower?.hp || maxHP;
  const hpPercentage = currentHP / maxHP;
  
  // Marvel-themed colors based on type and health
  const getBaseColor = () => {
    if (type === 'hero') {
      if (variant === 'main') {
        // Avengers Tower - gold and blue
        return hpPercentage > 0.5 ? '#1e3a8a' : hpPercentage > 0.25 ? '#d97706' : '#dc2626';
      } else {
        // SHIELD Turret - metallic blue
        return hpPercentage > 0.5 ? '#3b82f6' : hpPercentage > 0.25 ? '#f59e0b' : '#ef4444';
      }
    } else {
      if (variant === 'main') {
        // Hydra Base - dark green and black
        return hpPercentage > 0.5 ? '#166534' : hpPercentage > 0.25 ? '#dc2626' : '#7f1d1d';
      } else {
        // Chitauri Cannon - alien purple
        return hpPercentage > 0.5 ? '#7c3aed' : hpPercentage > 0.25 ? '#dc2626' : '#991b1b';
      }
    }
  };

  const getAccentColor = () => {
    if (type === 'hero') {
      return variant === 'main' ? '#fbbf24' : '#60a5fa'; // Gold for Avengers, light blue for SHIELD
    } else {
      return variant === 'main' ? '#22c55e' : '#a855f7'; // Green for Hydra, purple for Chitauri
    }
  };

  // Enhanced attack animation with smooth laser targeting
  useFrame((state, delta) => {
    // Tower attack animation
    if (meshRef.current && tower?.isAttacking) {
      meshRef.current.scale.setScalar(1 + Math.sin(state.clock.elapsedTime * 15) * 0.05);
    } else if (meshRef.current) {
      meshRef.current.scale.setScalar(1);
    }
    
    // Find current target (both when attacking and when ready to attack)
    // Use safe fallbacks for tower properties
    const safeType = tower?.type || type;
    const safePosition = tower?.position || position;
    
    const enemies = deployedCharacters.filter(char => 
      char.hp > 0 && 
      char.team !== safeType &&
      getDistance(safePosition, char.position) <= 5
    );
    
    const hasTarget = enemies.length > 0;
    const target = hasTarget ? enemies[0] : null;
    
    // Update targeting state only when it changes
    if (hasTarget !== isTargeting) {
      setIsTargeting(hasTarget);
    }
    
    // Update target position and laser progress using refs
    if (target) {
      targetPositionRef.current = target.position;
      
      if (tower?.isAttacking) {
        // Animate laser progress when attacking
        laserProgressRef.current = Math.min(laserProgressRef.current + delta * 8, 1);
      } else {
        // Reset progress when not attacking
        laserProgressRef.current = 0;
      }
    } else {
      targetPositionRef.current = null;
      laserProgressRef.current = 0;
      
      // Immediately hide beams when no target
      if (laserOuterRef.current) {
        laserOuterRef.current.visible = false;
      }
      if (laserInnerRef.current) {
        laserInnerRef.current.visible = false;
      }
    }
    
    // Update laser beam geometry with corrected growth math
    if (targetPositionRef.current && (laserOuterRef.current || laserInnerRef.current)) {
      // Local coordinates relative to tower
      const localStart = new THREE.Vector3(0, dimensions.base[1] / 2, dimensions.base[2] / 2 + 0.2);
      const worldTarget = new THREE.Vector3(...targetPositionRef.current);
      worldTarget.y += 0.5; // Aim at character center
      
      // Convert world target to local coordinates
      const towerWorldPos = new THREE.Vector3(...position);
      const localTarget = worldTarget.clone().sub(towerWorldPos);
      
      // Calculate direction and distance with epsilon guard
      const direction = localTarget.clone().sub(localStart);
      const distance = direction.length();
      
      // Add epsilon guard to prevent NaN when target is at muzzle
      if (distance < 0.001) {
        return;
      }
      
      const normalizedDirection = direction.clone().normalize();
      
      // Current end point based on laser progress (grows from muzzle)
      const currentEnd = localStart.clone().add(normalizedDirection.clone().multiplyScalar(distance * laserProgressRef.current));
      const currentDistance = distance * laserProgressRef.current;
      const midpoint = localStart.clone().add(normalizedDirection.clone().multiplyScalar(currentDistance * 0.5));
      
      // Create quaternion for proper orientation
      const quaternion = new THREE.Quaternion();
      quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normalizedDirection);
      
      // Update outer laser
      if (laserOuterRef.current) {
        laserOuterRef.current.position.copy(midpoint);
        laserOuterRef.current.quaternion.copy(quaternion);
        laserOuterRef.current.scale.set(1, currentDistance, 1);
        laserOuterRef.current.visible = currentDistance > 0;
      }
      
      // Update inner laser
      if (laserInnerRef.current) {
        laserInnerRef.current.position.copy(midpoint);
        laserInnerRef.current.quaternion.copy(quaternion);
        laserInnerRef.current.scale.set(1, currentDistance, 1);
        laserInnerRef.current.visible = currentDistance > 0;
      }
    }
  });

  // Helper function to calculate distance (same as in gameLogic.ts)
  const getDistance = (pos1: [number, number, number], pos2: [number, number, number]) => {
    const dx = pos1[0] - pos2[0];
    const dy = pos1[1] - pos2[1];
    const dz = pos1[2] - pos2[2];
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  };

  // Tower dimensions based on Marvel themes
  const getTowerDimensions = () => {
    if (type === 'hero') {
      if (variant === 'main') {
        // Avengers Tower - tall and sleek
        return { base: [2.5, 5, 2.5] as [number, number, number], top: [1, 2, 1] as [number, number, number] };
      } else {
        // SHIELD Turret - compact and tactical
        return { base: [1.8, 2.5, 1.8] as [number, number, number], top: [0.8, 1, 0.8] as [number, number, number] };
      }
    } else {
      if (variant === 'main') {
        // Hydra Base - fortress-like
        return { base: [3, 4, 3] as [number, number, number], top: [1.5, 1.5, 1.5] as [number, number, number] };
      } else {
        // Chitauri Cannon - alien and curved
        return { base: [1.5, 3, 1.5] as [number, number, number], top: [0.6, 1.5, 0.6] as [number, number, number] };
      }
    }
  };

  const dimensions = getTowerDimensions();

  return (
    <group position={position}>
      {/* Main tower base */}
      <mesh ref={meshRef} castShadow receiveShadow>
        <boxGeometry args={dimensions.base} />
        <meshLambertMaterial color={getBaseColor()} />
      </mesh>

      {/* Tower design elements based on Marvel theme */}
      {type === 'hero' && variant === 'main' && (
        <>
          {/* Avengers Tower - sleek top section */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1]/2, 0]} castShadow>
            <boxGeometry args={dimensions.top} />
            <meshLambertMaterial color={getAccentColor()} />
          </mesh>
          
          {/* Avengers A logo representation */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1] + 0.2, 0]}>
            <coneGeometry args={[0.4, 0.8, 3]} />
            <meshBasicMaterial color={getAccentColor()} />
          </mesh>
          
          {/* Arc reactor glow */}
          <mesh position={[0, dimensions.base[1]/2, dimensions.base[2]/2 + 0.1]}>
            <cylinderGeometry args={[0.3, 0.3, 0.1]} />
            <meshLambertMaterial color="#4dd0e1" emissive="#4dd0e1" emissiveIntensity={0.3} />
          </mesh>
        </>
      )}

      {type === 'hero' && variant === 'side' && (
        <>
          {/* SHIELD Turret design */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1]/2, 0]} castShadow>
            <cylinderGeometry args={[dimensions.top[0], dimensions.top[0], dimensions.top[1]]} />
            <meshLambertMaterial color={getAccentColor()} />
          </mesh>
          
          {/* SHIELD eagle emblem suggestion */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1], 0]}>
            <sphereGeometry args={[0.2]} />
            <meshBasicMaterial color="#fbbf24" />
          </mesh>
        </>
      )}

      {type === 'villain' && variant === 'main' && (
        <>
          {/* Hydra Base - fortress design */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1]/2, 0]} castShadow>
            <boxGeometry args={dimensions.top} />
            <meshLambertMaterial color="#1f2937" />
          </mesh>
          
          {/* Hydra skull logo representation */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1] + 0.2, 0]}>
            <sphereGeometry args={[0.3]} />
            <meshLambertMaterial color="#dc2626" emissive="#dc2626" emissiveIntensity={0.2} />
          </mesh>
          
          {/* Green energy core */}
          <mesh position={[0, dimensions.base[1]/2, dimensions.base[2]/2 + 0.1]}>
            <cylinderGeometry args={[0.3, 0.3, 0.1]} />
            <meshLambertMaterial color="#22c55e" emissive="#22c55e" emissiveIntensity={0.4} />
          </mesh>
        </>
      )}

      {type === 'villain' && variant === 'side' && (
        <>
          {/* Chitauri Cannon - alien design */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1]/2, 0]} castShadow>
            <coneGeometry args={[dimensions.top[0], dimensions.top[1], 6]} />
            <meshLambertMaterial color={getAccentColor()} />
          </mesh>
          
          {/* Alien energy core */}
          <mesh position={[0, dimensions.base[1]/2 + dimensions.top[1], 0]}>
            <sphereGeometry args={[0.15]} />
            <meshLambertMaterial color="#a855f7" emissive="#a855f7" emissiveIntensity={0.5} />
          </mesh>
        </>
      )}

      {/* Marvel-themed health bar */}
      <group position={[0, dimensions.base[1]/2 + dimensions.top[1] + 1, 0]}>
        <mesh>
          <planeGeometry args={[3, 0.3]} />
          <meshBasicMaterial color="#000000" opacity={0.8} transparent />
        </mesh>
        <mesh position={[-(1.5 - (1.5 * hpPercentage)), 0, 0.01]}>
          <planeGeometry args={[3 * hpPercentage, 0.25]} />
          <meshBasicMaterial 
            color={hpPercentage > 0.5 ? getAccentColor() : hpPercentage > 0.25 ? '#fbbf24' : '#dc2626'} 
            opacity={0.9} 
            transparent 
          />
        </mesh>
      </group>

      {/* Enhanced Marvel laser attack effects */}
      {tower?.isAttacking && (
        <group>
          {/* Smooth targeted laser beam */}
          <mesh ref={laserOuterRef} visible={false}>
            <cylinderGeometry args={[0.08, 0.12, 1]} />
            <meshLambertMaterial 
              color={type === 'hero' ? '#4dd0e1' : '#22c55e'} 
              emissive={type === 'hero' ? '#4dd0e1' : '#22c55e'} 
              emissiveIntensity={1.2}
              transparent
              opacity={0.9}
            />
          </mesh>
          
          {/* Inner laser core for intensity */}
          <mesh ref={laserInnerRef} visible={false}>
            <cylinderGeometry args={[0.03, 0.06, 1]} />
            <meshBasicMaterial 
              color={type === 'hero' ? '#ffffff' : '#ffffff'} 
              opacity={0.8}
              transparent
            />
          </mesh>
          
          {/* Muzzle flash with enhanced glow */}
          {targetPositionRef.current && (
            <mesh position={[0, dimensions.base[1]/2, dimensions.base[2]/2 + 0.2]}>
              <sphereGeometry args={[0.25]} />
              <meshLambertMaterial 
                color={type === 'hero' ? '#4dd0e1' : '#22c55e'} 
                emissive={type === 'hero' ? '#4dd0e1' : '#22c55e'} 
                emissiveIntensity={1.5}
                transparent
                opacity={0.7}
              />
            </mesh>
          )}
          
          {/* Outer glow ring */}
          <mesh position={[0, dimensions.base[1]/2, dimensions.base[2]/2 + 0.2]}>
            <sphereGeometry args={[0.4]} />
            <meshBasicMaterial 
              color={type === 'hero' ? '#4dd0e1' : '#22c55e'} 
              transparent
              opacity={0.3}
            />
          </mesh>
          
          {/* Energy particles around muzzle */}
          {Array.from({ length: 6 }).map((_, i) => {
            const angle = (i / 6) * Math.PI * 2;
            const radius = 0.6;
            return (
              <mesh
                key={i}
                position={[
                  Math.cos(angle) * radius,
                  dimensions.base[1]/2 + Math.sin(angle) * 0.1,
                  dimensions.base[2]/2 + 0.2 + Math.sin(angle) * radius
                ]}
              >
                <sphereGeometry args={[0.05]} />
                <meshBasicMaterial 
                  color={type === 'hero' ? '#87ceeb' : '#90ee90'} 
                  transparent
                  opacity={0.6}
                />
              </mesh>
            );
          })}
          
          {/* Impact effect at target */}
          {laserProgressRef.current > 0.7 && targetPositionRef.current && (
            <mesh position={[
              targetPositionRef.current[0] - position[0], 
              targetPositionRef.current[1] - position[1] + 0.5, 
              targetPositionRef.current[2] - position[2]
            ]}>
              <sphereGeometry args={[0.3]} />
              <meshBasicMaterial 
                color={type === 'hero' ? '#ffffff' : '#ffffff'} 
                transparent
                opacity={0.8}
              />
            </mesh>
          )}
          
          {/* Energy ripple at impact */}
          {laserProgressRef.current > 0.8 && targetPositionRef.current && (
            <mesh 
              position={[
                targetPositionRef.current[0] - position[0], 
                targetPositionRef.current[1] - position[1] + 0.5, 
                targetPositionRef.current[2] - position[2]
              ]} 
              rotation={[Math.PI/2, 0, 0]}
            >
              <torusGeometry args={[0.5, 0.05, 8, 16]} />
              <meshBasicMaterial 
                color={type === 'hero' ? '#4dd0e1' : '#22c55e'} 
                transparent
                opacity={0.5}
              />
            </mesh>
          )}
        </group>
      )}
      
      {/* Targeting indicator when aiming but not firing */}
      {!tower?.isAttacking && isTargeting && (
        <TargetingIndicator 
          type={type}
          targetPosition={targetPositionRef.current}
          towerPosition={position}
          dimensions={dimensions}
        />
      )}
    </group>
  );
}

// Separate component for targeting indicator with proper orientation
function TargetingIndicator({ 
  type, 
  targetPosition, 
  towerPosition, 
  dimensions 
}: {
  type: 'hero' | 'villain';
  targetPosition: [number, number, number] | null;
  towerPosition: [number, number, number];
  dimensions: any;
}) {
  const targetingLineRef = useRef<THREE.Mesh>(null);
  
  useFrame(() => {
    if (targetPosition && targetingLineRef.current) {
      // Local coordinates relative to tower
      const localStart = new THREE.Vector3(0, dimensions.base[1] / 2, dimensions.base[2] / 2 + 0.2);
      const worldTarget = new THREE.Vector3(...targetPosition);
      worldTarget.y += 0.5; // Aim at character center
      
      // Convert world target to local coordinates
      const towerWorldPos = new THREE.Vector3(...towerPosition);
      const localTarget = worldTarget.clone().sub(towerWorldPos);
      
      // Calculate direction and distance
      const direction = localTarget.clone().sub(localStart);
      const distance = direction.length();
      
      if (distance > 0.001) {
        const normalizedDirection = direction.clone().normalize();
        const midpoint = localStart.clone().add(direction.clone().multiplyScalar(0.5));
        
        // Create quaternion for proper orientation
        const quaternion = new THREE.Quaternion();
        quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), normalizedDirection);
        
        // Update targeting line
        targetingLineRef.current.position.copy(midpoint);
        targetingLineRef.current.quaternion.copy(quaternion);
        targetingLineRef.current.scale.set(1, distance, 1);
        targetingLineRef.current.visible = true;
      } else {
        targetingLineRef.current.visible = false;
      }
    } else if (targetingLineRef.current) {
      targetingLineRef.current.visible = false;
    }
  });
  
  return (
    <group>
      {/* Targeting laser sight */}
      <mesh position={[0, dimensions.base[1]/2, dimensions.base[2]/2 + 0.2]}>
        <sphereGeometry args={[0.1]} />
        <meshBasicMaterial 
          color={type === 'hero' ? '#ff6b6b' : '#ffa500'} 
          transparent
          opacity={0.8}
        />
      </mesh>
      
      {/* Oriented targeting line */}
      <mesh ref={targetingLineRef} visible={false}>
        <cylinderGeometry args={[0.02, 0.02, 1]} />
        <meshBasicMaterial 
          color={type === 'hero' ? '#ff6b6b' : '#ffa500'} 
          transparent
          opacity={0.4}
        />
      </mesh>
    </group>
  );
}
