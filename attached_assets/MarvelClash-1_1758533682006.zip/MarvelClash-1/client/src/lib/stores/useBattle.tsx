import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { Character } from '../../data/characters';

export interface Tower {
  id: string;
  type: 'hero' | 'villain';
  variant: 'main' | 'side';
  hp: number;
  maxHP: number;
  position: [number, number, number];
  isAttacking: boolean;
  lastAttackTime: number;
}

export interface DeployedCharacter {
  id: string;
  character: Character;
  team: 'hero' | 'villain';
  hp: number;
  position: [number, number, number];
  isAttacking: boolean;
  abilityActive: boolean;
  target: string | null;
  lastAttackTime: number;
  spawnTime: number;
}

export interface BattleResult {
  winner: 'hero' | 'villain' | 'draw';
  reason: string;
  timeRemaining: number;
  playerTowerHP: number;
  enemyTowerHP: number;
  cardsPlayed: number;
  damageDealt: number;
}

interface BattleState {
  // Battle status
  isInitialized: boolean;
  timeRemaining: number;
  isOvertime: boolean;
  battleResult: BattleResult | null;
  
  // Energy system
  currentEnergy: number;
  maxEnergy: number;
  lastEnergyUpdate: number;
  
  // Towers
  towers: Tower[];
  
  // Characters
  deployedCharacters: DeployedCharacter[];
  
  // Statistics
  cardsPlayed: number;
  totalDamageDealt: number;
  
  // Actions
  initializeBattle: () => void;
  resetBattle: () => void;
  updateTime: (deltaTime: number) => void;
  updateEnergy: (deltaTime: number) => void;
  deployCharacter: (character: Character, position: [number, number, number], team: 'hero' | 'villain') => string;
  removeCharacter: (id: string) => void;
  updateCharacterPosition: (id: string, position: [number, number, number]) => void;
  damageCharacter: (id: string, damage: number) => void;
  damageTower: (id: string, damage: number) => void;
  setCharacterAttacking: (id: string, attacking: boolean, target?: string) => void;
  setTowerAttacking: (id: string, attacking: boolean) => void;
  endBattle: (result: BattleResult) => void;
}

export const useBattle = create<BattleState>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    isInitialized: false,
    timeRemaining: 180, // 3 minutes
    isOvertime: false,
    battleResult: null,
    currentEnergy: 5, // Start with 5 energy
    maxEnergy: 10,
    lastEnergyUpdate: Date.now(),
    towers: [],
    deployedCharacters: [],
    cardsPlayed: 0,
    totalDamageDealt: 0,

    initializeBattle: () => {
      const now = Date.now();
      set({
        isInitialized: true,
        timeRemaining: 180,
        isOvertime: false,
        battleResult: null,
        currentEnergy: 5,
        lastEnergyUpdate: now,
        cardsPlayed: 0,
        totalDamageDealt: 0,
        towers: [
          // Hero towers
          {
            id: 'hero-main',
            type: 'hero',
            variant: 'main',
            hp: 4000,
            maxHP: 4000,
            position: [0, 1.5, 12],
            isAttacking: false,
            lastAttackTime: 0
          },
          {
            id: 'hero-left',
            type: 'hero',
            variant: 'side',
            hp: 2000,
            maxHP: 2000,
            position: [-6, 1, 8],
            isAttacking: false,
            lastAttackTime: 0
          },
          {
            id: 'hero-right',
            type: 'hero',
            variant: 'side',
            hp: 2000,
            maxHP: 2000,
            position: [6, 1, 8],
            isAttacking: false,
            lastAttackTime: 0
          },
          // Villain towers
          {
            id: 'villain-main',
            type: 'villain',
            variant: 'main',
            hp: 4000,
            maxHP: 4000,
            position: [0, 1.5, -12],
            isAttacking: false,
            lastAttackTime: 0
          },
          {
            id: 'villain-left',
            type: 'villain',
            variant: 'side',
            hp: 2000,
            maxHP: 2000,
            position: [-6, 1, -8],
            isAttacking: false,
            lastAttackTime: 0
          },
          {
            id: 'villain-right',
            type: 'villain',
            variant: 'side',
            hp: 2000,
            maxHP: 2000,
            position: [6, 1, -8],
            isAttacking: false,
            lastAttackTime: 0
          }
        ],
        deployedCharacters: []
      });
    },

    resetBattle: () => {
      set({
        isInitialized: false,
        timeRemaining: 180,
        isOvertime: false,
        battleResult: null,
        currentEnergy: 5,
        maxEnergy: 10,
        lastEnergyUpdate: Date.now(),
        towers: [],
        deployedCharacters: [],
        cardsPlayed: 0,
        totalDamageDealt: 0
      });
    },

    updateTime: (deltaTime: number) => {
      set((state) => {
        const newTime = Math.max(0, state.timeRemaining - deltaTime);
        const wasOvertime = state.isOvertime;
        const isOvertime = newTime <= 60 && newTime > 0; // Last minute

        // Check for battle end due to time
        if (newTime <= 0 && !state.battleResult) {
          const heroTower = state.towers.find(t => t.id === 'hero-main');
          const villainTower = state.towers.find(t => t.id === 'villain-main');
          
          let winner: 'hero' | 'villain' | 'draw' = 'draw';
          let reason = 'Time expired - Draw!';
          
          if (heroTower && villainTower) {
            if (heroTower.hp > villainTower.hp) {
              winner = 'hero';
              reason = 'Time expired - Your tower had more health!';
            } else if (villainTower.hp > heroTower.hp) {
              winner = 'villain';
              reason = 'Time expired - Enemy tower had more health!';
            }
          }

          return {
            ...state,
            timeRemaining: 0,
            isOvertime: false,
            battleResult: {
              winner,
              reason,
              timeRemaining: 0,
              playerTowerHP: heroTower?.hp || 0,
              enemyTowerHP: villainTower?.hp || 0,
              cardsPlayed: state.cardsPlayed,
              damageDealt: state.totalDamageDealt
            }
          };
        }

        return {
          ...state,
          timeRemaining: newTime,
          isOvertime: isOvertime && !wasOvertime ? true : state.isOvertime
        };
      });
    },

    updateEnergy: (deltaTime: number) => {
      set((state) => {
        const now = Date.now();
        const timeSinceLastUpdate = (now - state.lastEnergyUpdate) / 1000;
        const rechargeRate = state.isOvertime ? 1.25 : 2.5; // Faster recharge in overtime
        
        if (timeSinceLastUpdate >= rechargeRate && state.currentEnergy < state.maxEnergy) {
          return {
            ...state,
            currentEnergy: Math.min(state.maxEnergy, state.currentEnergy + 1),
            lastEnergyUpdate: now
          };
        }
        
        return state;
      });
    },

    deployCharacter: (character: Character, position: [number, number, number], team: 'hero' | 'villain') => {
      const id = `${character.id}-${Date.now()}-${Math.random()}`;
      
      set((state) => {
        // Check if player has enough energy
        if (team === 'hero' && state.currentEnergy < character.cost) {
          return state;
        }

        const deployedCharacter: DeployedCharacter = {
          id,
          character,
          team,
          hp: character.hp,
          position,
          isAttacking: false,
          abilityActive: false,
          target: null,
          lastAttackTime: 0,
          spawnTime: Date.now()
        };

        return {
          ...state,
          deployedCharacters: [...state.deployedCharacters, deployedCharacter],
          currentEnergy: team === 'hero' ? state.currentEnergy - character.cost : state.currentEnergy,
          cardsPlayed: team === 'hero' ? state.cardsPlayed + 1 : state.cardsPlayed
        };
      });

      return id;
    },

    removeCharacter: (id: string) => {
      set((state) => ({
        ...state,
        deployedCharacters: state.deployedCharacters.filter(char => char.id !== id)
      }));
    },

    updateCharacterPosition: (id: string, position: [number, number, number]) => {
      set((state) => ({
        ...state,
        deployedCharacters: state.deployedCharacters.map(char =>
          char.id === id ? { ...char, position } : char
        )
      }));
    },

    damageCharacter: (id: string, damage: number) => {
      set((state) => ({
        ...state,
        deployedCharacters: state.deployedCharacters.map(char =>
          char.id === id ? { ...char, hp: Math.max(0, char.hp - damage) } : char
        )
      }));
    },

    damageTower: (id: string, damage: number) => {
      set((state) => {
        const newTowers = state.towers.map(tower => {
          if (tower.id === id) {
            const newHP = Math.max(0, tower.hp - damage);
            
            // Check for battle end
            if (newHP <= 0 && tower.variant === 'main' && !state.battleResult) {
              const winner = tower.type === 'hero' ? 'villain' : 'hero';
              const reason = tower.type === 'hero' 
                ? 'Your main tower was destroyed!' 
                : 'Enemy main tower destroyed!';
              
              setTimeout(() => {
                get().endBattle({
                  winner,
                  reason,
                  timeRemaining: state.timeRemaining,
                  playerTowerHP: tower.type === 'hero' ? 0 : state.towers.find(t => t.id === 'hero-main')?.hp || 0,
                  enemyTowerHP: tower.type === 'villain' ? 0 : state.towers.find(t => t.id === 'villain-main')?.hp || 0,
                  cardsPlayed: state.cardsPlayed,
                  damageDealt: state.totalDamageDealt + damage
                });
              }, 100);
            }
            
            return { ...tower, hp: newHP };
          }
          return tower;
        });

        return {
          ...state,
          towers: newTowers,
          totalDamageDealt: state.totalDamageDealt + damage
        };
      });
    },

    setCharacterAttacking: (id: string, attacking: boolean, target?: string) => {
      set((state) => ({
        ...state,
        deployedCharacters: state.deployedCharacters.map(char =>
          char.id === id 
            ? { ...char, isAttacking: attacking, target: target || null, lastAttackTime: Date.now() }
            : char
        )
      }));
    },

    setTowerAttacking: (id: string, attacking: boolean) => {
      set((state) => ({
        ...state,
        towers: state.towers.map(tower =>
          tower.id === id 
            ? { ...tower, isAttacking: attacking, lastAttackTime: Date.now() }
            : tower
        )
      }));
    },

    endBattle: (result: BattleResult) => {
      set((state) => ({
        ...state,
        battleResult: result
      }));
    }
  }))
);
