import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import { Character, heroes, villains } from '../../data/characters';

interface DeckState {
  selectedDeck: Character[];
  activeCards: Character[];
  cardCycle: Character[];
  
  // Deck building
  addToDeck: (character: Character) => void;
  removeFromDeck: (characterId: string) => void;
  clearDeck: () => void;
  
  // Battle deck management
  initializeBattleDeck: (deck: Character[]) => void;
  useCard: (characterId: string) => void;
  drawNextCard: () => void;
  
  // Getters
  deckSize: number;
  isValidDeck: boolean;
}

// Default deck for quick start
const getDefaultDeck = (): Character[] => {
  const defaultHeroes = heroes.slice(0, 4);
  const defaultVillains = villains.slice(0, 4);
  return [...defaultHeroes, ...defaultVillains];
};

// Shuffle array utility
const shuffleArray = <T,>(array: T[]): T[] => {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
};

export const useDeck = create<DeckState>()(
  subscribeWithSelector((set, get) => ({
    selectedDeck: getDefaultDeck(),
    activeCards: [],
    cardCycle: [],

    addToDeck: (character: Character) => {
      set((state) => {
        if (state.selectedDeck.length >= 8) return state;
        if (state.selectedDeck.some(c => c.id === character.id)) return state;
        
        return {
          ...state,
          selectedDeck: [...state.selectedDeck, character]
        };
      });
    },

    removeFromDeck: (characterId: string) => {
      set((state) => ({
        ...state,
        selectedDeck: state.selectedDeck.filter(c => c.id !== characterId)
      }));
    },

    clearDeck: () => {
      set((state) => ({
        ...state,
        selectedDeck: []
      }));
    },

    initializeBattleDeck: (deck: Character[]) => {
      const shuffledDeck = shuffleArray(deck);
      const activeCards = shuffledDeck.slice(0, 4);
      const cardCycle = shuffledDeck.slice(4);
      
      set({
        selectedDeck: deck,
        activeCards,
        cardCycle: [...cardCycle, ...shuffledDeck.slice(0, 4)] // Create infinite cycle
      });
    },

    useCard: (characterId: string) => {
      set((state) => {
        const usedCardIndex = state.activeCards.findIndex(c => c.id === characterId);
        if (usedCardIndex === -1) return state;

        // Remove used card and add next card from cycle
        const newActiveCards = [...state.activeCards];
        const nextCard = state.cardCycle[0];
        const newCycle = [...state.cardCycle.slice(1)];
        
        // Add the used card back to the end of cycle for infinite rotation
        newCycle.push(state.activeCards[usedCardIndex]);
        newActiveCards[usedCardIndex] = nextCard;

        return {
          ...state,
          activeCards: newActiveCards,
          cardCycle: newCycle
        };
      });
    },

    drawNextCard: () => {
      set((state) => {
        if (state.cardCycle.length === 0) return state;

        const nextCard = state.cardCycle[0];
        const newCycle = state.cardCycle.slice(1);
        
        return {
          ...state,
          activeCards: [...state.activeCards.slice(1), nextCard],
          cardCycle: newCycle
        };
      });
    },

    // Computed properties
    get deckSize() {
      return get().selectedDeck.length;
    },

    get isValidDeck() {
      return get().selectedDeck.length === 8;
    }
  }))
);
