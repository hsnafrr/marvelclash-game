import { useState } from 'react';
import { useCards } from '../../lib/stores/useCards';
import { useDeck } from '../../lib/stores/useDeck';
import { Character } from '../../data/characters';
import { GameScreen } from '../../App';

interface CardCollectionProps {
  onNavigate: (screen: GameScreen) => void;
}

export default function CardCollection({ onNavigate }: CardCollectionProps) {
  const { heroes, villains } = useCards();
  const { selectedDeck, addToDeck, removeFromDeck, deckSize } = useDeck();
  const [selectedFaction, setSelectedFaction] = useState<'heroes' | 'villains'>('heroes');
  const [selectedCard, setSelectedCard] = useState<Character | null>(null);

  const currentCards = selectedFaction === 'heroes' ? heroes : villains;
  const maxDeckSize = 8;

  const handleCardClick = (character: Character) => {
    setSelectedCard(character);
  };

  const handleAddToDeck = (character: Character) => {
    if (deckSize < maxDeckSize) {
      addToDeck(character);
    }
  };

  const handleRemoveFromDeck = (character: Character) => {
    removeFromDeck(character.id);
  };

  const isInDeck = (character: Character) => {
    return selectedDeck.some(c => c.id === character.id);
  };

  const canStartBattle = deckSize === maxDeckSize;

  const getTypeColor = (character: Character) => {
    return character.faction === 'hero' ? 'from-blue-500 to-blue-700' : 'from-red-500 to-red-700';
  };

  const getRarityBorder = (character: Character) => {
    if (character.cost >= 7) return 'border-yellow-400'; // Legendary
    if (character.cost >= 5) return 'border-purple-400'; // Epic
    if (character.cost >= 3) return 'border-blue-400'; // Rare
    return 'border-gray-400'; // Common
  };

  return (
    <div className="w-full h-full bg-gradient-to-br from-gray-900 to-black text-white overflow-hidden flex">
      {/* Left Panel - Card Grid */}
      <div className="flex-1 p-6 overflow-y-auto">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-3xl font-bold mb-4">Card Collection</h1>
          
          {/* Faction tabs */}
          <div className="flex gap-4 mb-6">
            <button
              onClick={() => setSelectedFaction('heroes')}
              className={`px-6 py-3 rounded-lg font-bold transition-all ${
                selectedFaction === 'heroes'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              🦸 Heroes ({heroes.length})
            </button>
            <button
              onClick={() => setSelectedFaction('villains')}
              className={`px-6 py-3 rounded-lg font-bold transition-all ${
                selectedFaction === 'villains'
                  ? 'bg-red-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              🦹 Villains ({villains.length})
            </button>
          </div>
        </div>

        {/* Card grid */}
        <div className="grid grid-cols-5 gap-4">
          {currentCards.map((character) => (
            <div
              key={character.id}
              onClick={() => handleCardClick(character)}
              className={`
                relative cursor-pointer transform transition-all hover:scale-105
                bg-gradient-to-b ${getTypeColor(character)}
                rounded-lg border-2 ${getRarityBorder(character)}
                ${isInDeck(character) ? 'ring-4 ring-green-400' : ''}
                ${selectedCard?.id === character.id ? 'ring-4 ring-yellow-400' : ''}
                p-3 shadow-lg
              `}
            >
              {/* Energy cost */}
              <div className="absolute -top-2 -left-2 w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center text-white font-bold border-2 border-white">
                {character.cost}
              </div>

              {/* In deck indicator */}
              {isInDeck(character) && (
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                  <span className="text-white text-sm">✓</span>
                </div>
              )}

              {/* Character portrait */}
              <div className="w-full h-20 bg-black bg-opacity-30 rounded mb-2 flex items-center justify-center">
                <div className="w-12 h-12 rounded-full bg-white bg-opacity-90 flex items-center justify-center">
                  <span className="text-sm font-bold text-gray-800">
                    {character.name.slice(0, 2).toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Character info */}
              <div className="text-center text-white">
                <div className="font-bold text-sm mb-1 truncate">{character.name}</div>
                <div className="flex justify-between text-xs mb-1">
                  <span>❤{character.hp}</span>
                  <span>⚔{character.damage}</span>
                </div>
                <div className="text-xs opacity-75">{character.range}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Right Panel - Deck and Details */}
      <div className="w-80 bg-gray-800 p-6 flex flex-col">
        {/* Deck section */}
        <div className="mb-6">
          <h2 className="text-xl font-bold mb-3">
            Battle Deck ({deckSize}/{maxDeckSize})
          </h2>
          
          {/* Deck cards */}
          <div className="space-y-2 mb-4 max-h-64 overflow-y-auto">
            {selectedDeck.map((character) => (
              <div
                key={character.id}
                className="flex items-center gap-3 bg-gray-700 p-2 rounded"
              >
                <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${getTypeColor(character)}`} />
                <div className="flex-1 text-sm">{character.name}</div>
                <div className="text-xs text-purple-400">{character.cost}</div>
                <button
                  onClick={() => handleRemoveFromDeck(character)}
                  className="text-red-400 hover:text-red-300 text-sm"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>

          {/* Action buttons */}
          <div className="space-y-2">
            {selectedCard && !isInDeck(selectedCard) && deckSize < maxDeckSize && (
              <button
                onClick={() => handleAddToDeck(selectedCard)}
                className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition-colors"
              >
                Add to Deck
              </button>
            )}
            
            <button
              onClick={() => canStartBattle && onNavigate('battle')}
              disabled={!canStartBattle}
              className={`w-full font-bold py-3 px-4 rounded transition-all ${
                canStartBattle
                  ? 'bg-blue-600 hover:bg-blue-700 text-white transform hover:scale-105'
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
              }`}
            >
              {canStartBattle ? '⚔️ START BATTLE' : `Need ${maxDeckSize - deckSize} more cards`}
            </button>
          </div>
        </div>

        {/* Card details */}
        {selectedCard && (
          <div className="flex-1 bg-gray-700 rounded-lg p-4">
            <h3 className="text-lg font-bold mb-3">{selectedCard.name}</h3>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Energy Cost:</span>
                <span className="text-purple-400 font-bold">{selectedCard.cost}</span>
              </div>
              <div className="flex justify-between">
                <span>Health:</span>
                <span className="text-green-400">{selectedCard.hp}</span>
              </div>
              <div className="flex justify-between">
                <span>Damage:</span>
                <span className="text-red-400">{selectedCard.damage}</span>
              </div>
              <div className="flex justify-between">
                <span>Speed:</span>
                <span className="text-blue-400">{selectedCard.speed}</span>
              </div>
              <div className="flex justify-between">
                <span>Range:</span>
                <span className="text-yellow-400">{selectedCard.range}</span>
              </div>
            </div>

            {selectedCard.ability && (
              <div className="mt-4 p-3 bg-gray-600 rounded">
                <div className="font-bold text-yellow-400 mb-1">Special Ability</div>
                <div className="text-xs">{selectedCard.ability}</div>
              </div>
            )}
          </div>
        )}

        {/* Back button */}
        <button
          onClick={() => onNavigate('menu')}
          className="mt-4 bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded transition-colors"
        >
          ← Back to Menu
        </button>
      </div>
    </div>
  );
}
