import { useState } from 'react';
import { setAIDifficulty, getCurrentDifficulty } from '../../lib/ai';

interface DifficultySelectorProps {
  onClose?: () => void;
}

type AIDifficulty = 'easy' | 'medium' | 'hard';

const difficultyConfig = {
  easy: {
    name: 'Easy',
    description: 'AI plays casually with random strategies',
    icon: '😌',
    color: 'from-green-500 to-green-700',
    features: ['Random deployments', 'Slow reactions', 'Basic strategies']
  },
  medium: {
    name: 'Medium', 
    description: 'AI uses balanced tactics and responds to threats',
    icon: '🤔',
    color: 'from-blue-500 to-blue-700',
    features: ['Strategic thinking', 'Threat assessment', 'Lane balancing']
  },
  hard: {
    name: 'Hard',
    description: 'AI uses advanced tactics and counter-strategies',
    icon: '😤',
    color: 'from-red-500 to-red-700',
    features: ['Counter strategies', 'Energy management', 'Tactical positioning']
  }
};

export default function DifficultySelector({ onClose }: DifficultySelectorProps) {
  const [selectedDifficulty, setSelectedDifficulty] = useState<AIDifficulty>(getCurrentDifficulty());

  const handleDifficultySelect = (difficulty: AIDifficulty) => {
    setSelectedDifficulty(difficulty);
    setAIDifficulty(difficulty);
  };

  const handleConfirm = () => {
    setAIDifficulty(selectedDifficulty);
    if (onClose) onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-900 rounded-lg p-6 w-96 max-w-90vw border border-gray-700">
        <h2 className="text-2xl font-bold text-white mb-4 text-center">
          Select AI Difficulty
        </h2>
        
        <div className="space-y-4 mb-6">
          {(Object.entries(difficultyConfig) as [AIDifficulty, typeof difficultyConfig.easy][]).map(([key, config]) => (
            <div
              key={key}
              onClick={() => handleDifficultySelect(key)}
              className={`
                relative cursor-pointer rounded-lg p-4 transition-all duration-200
                bg-gradient-to-r ${config.color}
                ${selectedDifficulty === key ? 'ring-4 ring-yellow-400 scale-105' : 'opacity-80 hover:opacity-100 hover:scale-102'}
                transform
              `}
            >
              <div className="flex items-start gap-3">
                <div className="text-2xl">{config.icon}</div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-white mb-1">
                    {config.name}
                  </h3>
                  <p className="text-sm text-gray-200 mb-2">
                    {config.description}
                  </p>
                  <ul className="space-y-1">
                    {config.features.map((feature, index) => (
                      <li key={index} className="text-xs text-gray-300 flex items-center gap-1">
                        <span className="w-1 h-1 bg-white rounded-full"></span>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                {selectedDifficulty === key && (
                  <div className="absolute top-2 right-2">
                    <div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">
                      <span className="text-gray-900 text-sm">✓</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          {onClose && (
            <button
              onClick={onClose}
              className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-bold py-3 px-4 rounded-lg transition-colors"
            >
              Cancel
            </button>
          )}
          <button
            onClick={handleConfirm}
            className="flex-1 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-3 px-4 rounded-lg transition-all transform hover:scale-105"
          >
            Confirm
          </button>
        </div>
      </div>
    </div>
  );
}