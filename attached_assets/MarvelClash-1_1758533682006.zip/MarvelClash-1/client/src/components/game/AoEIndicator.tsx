import { useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import * as THREE from 'three';

interface AoEIndicatorProps {
  characterName: string;
  abilityActive: boolean;
  position: [number, number, number];
  show: boolean;
}

export function AoEIndicator({ characterName, abilityActive, position, show }: AoEIndicatorProps) {
  const groupRef = useRef<THREE.Group>(null);
  const timeRef = useRef(0);

  useFrame((state, delta) => {
    timeRef.current += delta;
    if (!groupRef.current || !show) return;

    // Update AoE indicators with pulsing and scaling effects
    updateAoEIndicator(groupRef.current, timeRef.current, characterName, abilityActive);
  });

  if (!show) return null;

  return (
    <group ref={groupRef} position={position}>
      {getAoEGeometry(characterName, abilityActive)}
    </group>
  );
}

function getAoEGeometry(characterName: string, abilityActive: boolean) {
  const aoeData = getAoEData(characterName);
  if (!aoeData) return null;

  const { radius, color, shape, height } = aoeData;

  switch (shape) {
    case 'circle':
      return (
        <group>
          {/* Base indicator circle */}
          <mesh position={[0, 0.1, 0]} rotation={[Math.PI/2, 0, 0]}>
            <torusGeometry args={[radius, 0.1, 8, 32]} />
            <meshBasicMaterial color={color} transparent opacity={abilityActive ? 0.6 : 0.3} />
          </mesh>
          {/* Inner filled area */}
          <mesh position={[0, 0.05, 0]} rotation={[Math.PI/2, 0, 0]}>
            <circleGeometry args={[radius, 32]} />
            <meshBasicMaterial color={color} transparent opacity={abilityActive ? 0.2 : 0.1} />
          </mesh>
          {/* Warning markers */}
          {Array.from({length: 8}).map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos((i / 8) * Math.PI * 2) * radius,
                0.2,
                Math.sin((i / 8) * Math.PI * 2) * radius
              ]}
            >
              <coneGeometry args={[0.1, 0.3, 4]} />
              <meshBasicMaterial color={color} />
            </mesh>
          ))}
        </group>
      );

    case 'line':
      return (
        <group>
          {/* Line AoE indicator */}
          <mesh position={[0, 0.1, -radius/2]} rotation={[Math.PI/2, 0, 0]}>
            <boxGeometry args={[1, radius, 0.1]} />
            <meshBasicMaterial color={color} transparent opacity={abilityActive ? 0.6 : 0.3} />
          </mesh>
          {/* Direction indicators */}
          {Array.from({length: 5}).map((_, i) => (
            <mesh
              key={i}
              position={[0, 0.2, -i * (radius/4)]}
            >
              <coneGeometry args={[0.1, 0.2, 3]} />
              <meshBasicMaterial color={color} />
            </mesh>
          ))}
        </group>
      );

    case 'burst':
      return (
        <group>
          {/* Burst indicator with multiple rings */}
          {Array.from({length: 3}).map((_, i) => (
            <mesh
              key={i}
              position={[0, 0.1 + i * 0.05, 0]}
              rotation={[Math.PI/2, 0, 0]}
            >
              <torusGeometry args={[radius + i * 0.5, 0.08 - i * 0.02, 8, 32]} />
              <meshBasicMaterial 
                color={color} 
                transparent 
                opacity={(abilityActive ? 0.6 : 0.3) - i * 0.1} 
              />
            </mesh>
          ))}
          {/* Energy spikes */}
          {Array.from({length: 12}).map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos((i / 12) * Math.PI * 2) * (radius + 0.5),
                height || 0.5,
                Math.sin((i / 12) * Math.PI * 2) * (radius + 0.5)
              ]}
            >
              <cylinderGeometry args={[0.05, 0.1, height || 1, 6]} />
              <meshBasicMaterial color={color} />
            </mesh>
          ))}
        </group>
      );

    case 'wave':
      return (
        <group>
          {/* Wave effect expanding outward */}
          {Array.from({length: 4}).map((_, i) => (
            <mesh
              key={i}
              position={[0, 0.1, 0]}
              rotation={[Math.PI/2, 0, 0]}
            >
              <torusGeometry args={[radius - i * 0.8, 0.1, 8, 32]} />
              <meshBasicMaterial 
                color={color} 
                transparent 
                opacity={(abilityActive ? 0.7 : 0.4) - i * 0.15} 
              />
            </mesh>
          ))}
        </group>
      );

    default:
      return null;
  }
}

function getAoEData(characterName: string) {
  const aoeMap: Record<string, { radius: number; color: string; shape: 'circle' | 'line' | 'burst' | 'wave'; height?: number }> = {
    // Heroes with AoE abilities
    'Thor': { radius: 4, color: '#87CEEB', shape: 'circle' },
    'Hulk': { radius: 3, color: '#32CD32', shape: 'burst', height: 1 },
    'Doctor Strange': { radius: 5, color: '#9932CC', shape: 'circle' },
    'Scarlet Witch': { radius: 4, color: '#DC143C', shape: 'wave' },
    'Captain Marvel': { radius: 6, color: '#FFD700', shape: 'burst', height: 2 },
    'Hawkeye': { radius: 2, color: '#32CD32', shape: 'circle' },
    'Falcon': { radius: 3, color: '#4169E1', shape: 'line' },
    'Winter Soldier': { radius: 2, color: '#708090', shape: 'circle' },
    'Iron Man': { radius: 8, color: '#FFD700', shape: 'line' },
    
    // Villains with AoE abilities
    'Thanos': { radius: 10, color: '#800080', shape: 'wave' },
    'Dormammu': { radius: 7, color: '#FF4500', shape: 'burst', height: 3 },
    'Magneto': { radius: 5, color: '#4B0082', shape: 'circle' },
    'Hela': { radius: 4, color: '#000000', shape: 'circle' },
    'Ultron': { radius: 3, color: '#FF0000', shape: 'circle' },
    'Red Skull': { radius: 3, color: '#DC143C', shape: 'circle' },
    'Kingpin': { radius: 3, color: '#FFFFFF', shape: 'burst', height: 1 },
    'Ronan': { radius: 6, color: '#4B0082', shape: 'line' },
    'Green Goblin': { radius: 4, color: '#228B22', shape: 'circle' },
    'Mysterio': { radius: 5, color: '#9932CC', shape: 'wave' }
  };

  return aoeMap[characterName] || null;
}

function updateAoEIndicator(group: THREE.Group, time: number, characterName: string, abilityActive: boolean) {
  const pulseSpeed = abilityActive ? 8 : 4;
  const pulseIntensity = abilityActive ? 0.3 : 0.1;

  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      const material = child.material as THREE.MeshBasicMaterial;
      
      if (child.geometry instanceof THREE.TorusGeometry) {
        // Pulsing ring effect
        child.scale.setScalar(1 + Math.sin(time * pulseSpeed + i) * pulseIntensity);
        material.opacity = (abilityActive ? 0.6 : 0.3) + Math.sin(time * pulseSpeed * 2 + i) * 0.2;
      } else if (child.geometry instanceof THREE.CircleGeometry) {
        // Pulsing fill effect
        material.opacity = (abilityActive ? 0.2 : 0.1) + Math.sin(time * pulseSpeed) * 0.1;
      } else if (child.geometry instanceof THREE.ConeGeometry) {
        // Warning markers bobbing
        child.position.y = 0.2 + Math.sin(time * pulseSpeed * 2 + i * 2) * 0.1;
        child.rotation.y = time + i;
      } else if (child.geometry instanceof THREE.BoxGeometry) {
        // Line AoE pulsing
        child.scale.setScalar(1 + Math.sin(time * pulseSpeed) * pulseIntensity);
        material.opacity = (abilityActive ? 0.6 : 0.3) + Math.sin(time * pulseSpeed * 1.5) * 0.2;
      } else if (child.geometry instanceof THREE.CylinderGeometry) {
        // Energy spikes growing
        child.scale.y = 1 + Math.sin(time * pulseSpeed + i * 0.5) * 0.4;
        child.rotation.y = time * 0.5 + i;
      }
    } else if (child instanceof THREE.Group) {
      // Handle nested groups recursively
      updateAoEIndicator(child, time, characterName, abilityActive);
    }
  });

  // Special character-specific updates
  switch (characterName) {
    case 'Scarlet Witch':
      // Reality warp wave effect
      group.rotation.y = time * 0.5;
      break;
      
    case 'Captain Marvel':
      // Supernova expanding bursts
      group.children.forEach((child, i) => {
        if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
          const phase = (time * 3 + i * 2) % (Math.PI * 2);
          child.scale.setScalar(1 + Math.sin(phase) * 0.5);
        }
      });
      break;
      
    case 'Thor':
      // Lightning storm crackling
      if (Math.random() > 0.7) {
        group.children.forEach((child) => {
          if (child instanceof THREE.Mesh) {
            const material = child.material as THREE.MeshBasicMaterial;
            material.opacity *= 1.5;
          }
        });
      }
      break;
      
    case 'Dormammu':
      // Dark energy swirling
      group.rotation.y = -time * 0.8;
      group.children.forEach((child, i) => {
        if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
          child.position.y += Math.sin(time * 4 + i) * 0.1;
        }
      });
      break;
  }
}