import { useEffect, useState } from 'react';
import { useBattle } from '../../lib/stores/useBattle';

export default function EnergyBar() {
  const { currentEnergy, maxEnergy, isOvertime } = useBattle();
  const [lastEnergy, setLastEnergy] = useState(currentEnergy);
  const [newStoneAnimation, setNewStoneAnimation] = useState<number | null>(null);
  
  // Infinity Stone colors and names
  const infinityStones = [
    { name: 'Space', color: '#4dd0e1', glowColor: '#b3e5fc' },      // Blue
    { name: 'Mind', color: '#ffeb3b', glowColor: '#fff9c4' },       // Yellow
    { name: 'Reality', color: '#f44336', glowColor: '#ffcdd2' },    // Red
    { name: 'Power', color: '#9c27b0', glowColor: '#e1bee7' },      // Purple
    { name: 'Time', color: '#4caf50', glowColor: '#c8e6c9' },       // Green
    { name: 'Soul', color: '#ff9800', glowColor: '#ffe0b2' },       // Orange
    { name: 'Space2', color: '#4dd0e1', glowColor: '#b3e5fc' },     // Blue (repeat)
    { name: 'Mind2', color: '#ffeb3b', glowColor: '#fff9c4' },      // Yellow (repeat)
    { name: 'Reality2', color: '#f44336', glowColor: '#ffcdd2' },   // Red (repeat)
    { name: 'Power2', color: '#9c27b0', glowColor: '#e1bee7' }      // Purple (repeat)
  ];
  
  // Detect when energy increases for animation
  useEffect(() => {
    if (currentEnergy > lastEnergy) {
      setNewStoneAnimation(Math.floor(currentEnergy) - 1);
      const timeout = setTimeout(() => setNewStoneAnimation(null), 1000);
      return () => clearTimeout(timeout);
    }
    setLastEnergy(currentEnergy);
  }, [currentEnergy, lastEnergy]);
  
  const energyPercentage = (currentEnergy / maxEnergy) * 100;
  
  return (
    <div className="flex items-center gap-3 bg-black bg-opacity-70 px-4 py-2 rounded-lg border border-purple-500 shadow-lg">
      {/* Infinity Stones Container */}
      <div className="flex items-center gap-2">
        <div className="text-yellow-300 font-bold text-sm mr-2">
          INFINITY STONES
        </div>
        
        {/* Individual Infinity Stones */}
        <div className="flex gap-1">
          {Array.from({ length: maxEnergy }).map((_, i) => {
            const stone = infinityStones[i % infinityStones.length];
            const isActive = i < Math.floor(currentEnergy);
            const isAnimating = newStoneAnimation === i;
            
            return (
              <div
                key={i}
                className={`relative w-6 h-6 rounded-full border-2 transition-all duration-500 ${
                  isActive 
                    ? `border-white shadow-lg ${isAnimating ? 'animate-pulse scale-125' : 'scale-100'}` 
                    : 'border-gray-600 scale-90 opacity-50'
                }`}
                style={{
                  backgroundColor: isActive ? stone.color : '#1a1a1a',
                  boxShadow: isActive 
                    ? `0 0 10px ${stone.glowColor}, 0 0 20px ${stone.color}40, inset 0 0 10px ${stone.glowColor}` 
                    : 'none'
                }}
              >
                {/* Stone inner glow effect */}
                {isActive && (
                  <div 
                    className="absolute inset-1 rounded-full opacity-60"
                    style={{
                      backgroundColor: stone.glowColor,
                      filter: 'blur(2px)'
                    }}
                  />
                )}
                
                {/* Stone core */}
                <div 
                  className={`absolute inset-2 rounded-full ${isActive ? 'opacity-80' : 'opacity-20'}`}
                  style={{
                    backgroundColor: isActive ? '#ffffff' : '#333333'
                  }}
                />
                
                {/* Pulsing energy effect for active stones */}
                {isActive && (
                  <div 
                    className="absolute inset-0 rounded-full animate-ping opacity-30"
                    style={{ backgroundColor: stone.color }}
                  />
                )}
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Energy counter */}
      <div className="text-white font-bold text-sm bg-gray-800 px-2 py-1 rounded">
        {Math.floor(currentEnergy)}/{maxEnergy}
      </div>
      
      {/* Cosmic energy bar */}
      <div className="w-32 h-3 bg-gray-800 rounded-full border border-purple-400 relative overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-500 ${
            isOvertime 
              ? 'bg-gradient-to-r from-orange-400 via-yellow-400 to-red-400' 
              : 'bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-400'
          }`}
          style={{ width: `${energyPercentage}%` }}
        />
        
        {/* Cosmic particle effect */}
        <div className={`absolute inset-0 ${
          isOvertime ? 'animate-pulse' : ''
        }`}>
          {Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full opacity-60 animate-ping"
              style={{
                left: `${20 + i * 30}%`,
                top: '25%',
                animationDelay: `${i * 0.3}s`,
                animationDuration: '2s'
              }}
            />
          ))}
        </div>
      </div>
      
      {/* Overtime cosmic indicator */}
      {isOvertime && (
        <div className="text-orange-300 font-bold text-xs animate-pulse bg-orange-900 px-2 py-1 rounded border border-orange-400">
          ⚡ COSMIC SURGE! ⚡
        </div>
      )}
    </div>
  );
}
