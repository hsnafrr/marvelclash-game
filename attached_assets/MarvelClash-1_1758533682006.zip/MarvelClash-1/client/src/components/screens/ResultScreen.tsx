import { useBattle } from '../../lib/stores/useBattle';
import { useGame } from '../../lib/stores/useGame';
import { GameScreen } from '../../App';

interface ResultScreenProps {
  onNavigate: (screen: GameScreen) => void;
}

export default function ResultScreen({ onNavigate }: ResultScreenProps) {
  const { battleResult, resetBattle } = useBattle();
  const { restart } = useGame();

  if (!battleResult) {
    onNavigate('menu');
    return null;
  }

  const handlePlayAgain = () => {
    resetBattle();
    restart();
    onNavigate('collection');
  };

  const handleMainMenu = () => {
    resetBattle();
    restart();
    onNavigate('menu');
  };

  const isVictory = battleResult.winner === 'hero';
  const isDraw = battleResult.winner === 'draw';

  return (
    <div className="w-full h-full relative overflow-hidden">
      {/* Background */}
      <div className={`absolute inset-0 ${
        isVictory 
          ? 'bg-gradient-to-br from-blue-900 via-blue-700 to-green-800'
          : isDraw
            ? 'bg-gradient-to-br from-gray-800 via-gray-700 to-gray-900'
            : 'bg-gradient-to-br from-red-900 via-red-700 to-black'
      }`}>
        {/* Animated particles */}
        <div className="absolute inset-0 opacity-30">
          {Array.from({ length: 100 }).map((_, i) => (
            <div
              key={i}
              className={`absolute w-2 h-2 rounded-full animate-pulse ${
                isVictory ? 'bg-yellow-400' : isDraw ? 'bg-gray-400' : 'bg-red-400'
              }`}
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${1 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full p-8 text-white">
        {/* Result header */}
        <div className="text-center mb-12">
          <h1 className={`text-8xl font-bold mb-6 ${
            isVictory ? 'text-yellow-400' : isDraw ? 'text-gray-300' : 'text-red-400'
          }`}>
            {isVictory ? 'VICTORY!' : isDraw ? 'DRAW!' : 'DEFEAT!'}
          </h1>
          
          <p className="text-2xl text-gray-300 mb-4">
            {battleResult.reason}
          </p>
          
          {isVictory && (
            <div className="text-lg text-yellow-300 animate-pulse">
              🏆 The Avengers have prevailed! 🏆
            </div>
          )}
          
          {!isVictory && !isDraw && (
            <div className="text-lg text-red-300">
              😈 The villains have conquered! 😈
            </div>
          )}
          
          {isDraw && (
            <div className="text-lg text-gray-300">
              ⚖️ A balanced battle! ⚖️
            </div>
          )}
        </div>

        {/* Battle statistics */}
        <div className="bg-black bg-opacity-50 rounded-lg p-6 mb-8 w-96">
          <h3 className="text-xl font-bold mb-4 text-center">Battle Statistics</h3>
          
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Battle Duration:</span>
              <span className="font-bold">
                {Math.floor((180 - (battleResult.timeRemaining || 0)) / 60)}:
                {((180 - (battleResult.timeRemaining || 0)) % 60).toString().padStart(2, '0')}
              </span>
            </div>
            
            <div className="flex justify-between">
              <span>Your Tower HP:</span>
              <span className={`font-bold ${
                battleResult.playerTowerHP > 2000 ? 'text-green-400' : 
                battleResult.playerTowerHP > 1000 ? 'text-yellow-400' : 'text-red-400'
              }`}>
                {battleResult.playerTowerHP}/4000
              </span>
            </div>
            
            <div className="flex justify-between">
              <span>Enemy Tower HP:</span>
              <span className={`font-bold ${
                battleResult.enemyTowerHP > 2000 ? 'text-red-400' : 
                battleResult.enemyTowerHP > 1000 ? 'text-yellow-400' : 'text-green-400'
              }`}>
                {battleResult.enemyTowerHP}/4000
              </span>
            </div>
            
            <div className="flex justify-between">
              <span>Cards Played:</span>
              <span className="font-bold">{battleResult.cardsPlayed || 0}</span>
            </div>
            
            <div className="flex justify-between">
              <span>Total Damage Dealt:</span>
              <span className="font-bold text-orange-400">
                {battleResult.damageDealt || 0}
              </span>
            </div>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex flex-col gap-4 w-80">
          <button
            onClick={handlePlayAgain}
            className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-bold py-4 px-8 rounded-lg text-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            🔄 PLAY AGAIN
          </button>
          
          <button
            onClick={handleMainMenu}
            className="bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            🏠 MAIN MENU
          </button>
        </div>

        {/* Achievement/flavor text */}
        <div className="mt-8 text-center text-gray-400">
          {isVictory && (
            <p className="italic">
              "I can do this all day!" - Captain America
            </p>
          )}
          {!isVictory && !isDraw && (
            <p className="italic">
              "I am inevitable." - Thanos
            </p>
          )}
          {isDraw && (
            <p className="italic">
              "Sometimes the best battles end in respect for your opponent."
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
