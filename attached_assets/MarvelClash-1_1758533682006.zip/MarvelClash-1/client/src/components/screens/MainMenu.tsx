import { useState } from 'react';
import { useAudio } from '../../lib/stores/useAudio';
import { GameScreen } from '../../App';
import DifficultySelector from '../ui/DifficultySelector';
import { getCurrentDifficulty } from '../../lib/ai';

interface MainMenuProps {
  onNavigate: (screen: GameScreen) => void;
}

export default function MainMenu({ onNavigate }: MainMenuProps) {
  const { toggleMute, isMuted } = useAudio();
  const [showDifficultySelector, setShowDifficultySelector] = useState(false);

  const handlePlayClick = () => {
    onNavigate('collection');
  };

  return (
    <div className="w-full h-full relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-blue-900 via-purple-900 to-black">
        {/* Animated background elements */}
        <div className="absolute inset-0 opacity-20">
          {Array.from({ length: 50 }).map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 2}s`
              }}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center h-full p-8">
        {/* Title */}
        <div className="text-center mb-12">
          <h1 className="text-6xl font-bold text-white mb-4 tracking-wider">
            MARVEL
          </h1>
          <h2 className="text-4xl font-bold text-yellow-400 mb-2">
            TOWER CLASH
          </h2>
          <p className="text-xl text-gray-300">
            Heroes vs Villains
          </p>
        </div>

        {/* Menu buttons */}
        <div className="flex flex-col gap-6 w-80">
          <button
            onClick={handlePlayClick}
            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold py-4 px-8 rounded-lg text-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            ⚔️ BATTLE
          </button>
          
          <button
            onClick={() => onNavigate('collection')}
            className="bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white font-bold py-4 px-8 rounded-lg text-xl transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            🎴 CARD COLLECTION
          </button>
          
          <button
            onClick={() => setShowDifficultySelector(true)}
            className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all duration-200 transform hover:scale-105 shadow-lg"
          >
            ⚙️ AI DIFFICULTY: {getCurrentDifficulty().toUpperCase()}
          </button>
          
          <button
            onClick={toggleMute}
            className={`${
              isMuted 
                ? 'bg-gradient-to-r from-gray-600 to-gray-700' 
                : 'bg-gradient-to-r from-yellow-600 to-orange-600'
            } hover:opacity-80 text-white font-bold py-3 px-8 rounded-lg text-lg transition-all duration-200 transform hover:scale-105 shadow-lg`}
          >
            {isMuted ? '🔇 UNMUTE SOUND' : '🔊 MUTE SOUND'}
          </button>
        </div>

        {/* Version info */}
        <div className="absolute bottom-4 text-gray-400 text-sm">
          v1.0.0 - Offline Edition
        </div>
      </div>
      
      {/* Difficulty Selector Modal */}
      {showDifficultySelector && (
        <DifficultySelector onClose={() => setShowDifficultySelector(false)} />
      )}
    </div>
  );
}
