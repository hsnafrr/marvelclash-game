import { Canvas } from "@react-three/fiber";
import { Suspense, useEffect, useState } from "react";
import { useGame } from "./lib/stores/useGame";
import { useBattle } from "./lib/stores/useBattle";
import { useAudio } from "./lib/stores/useAudio";
import "@fontsource/inter";

// Import screen components
import MainMenu from "./components/screens/MainMenu";
import CardCollection from "./components/screens/CardCollection";
import BattleScreen from "./components/screens/BattleScreen";
import ResultScreen from "./components/screens/ResultScreen";

export type GameScreen = 'menu' | 'collection' | 'battle' | 'result';

function App() {
  const [currentScreen, setCurrentScreen] = useState<GameScreen>('menu');
  const { phase } = useGame();
  const { battleResult } = useBattle();

  // Initialize audio
  useEffect(() => {
    const initAudio = async () => {
      try {
        const bgMusic = new Audio('/sounds/background.mp3');
        const hitSound = new Audio('/sounds/hit.mp3');
        const successSound = new Audio('/sounds/success.mp3');
        
        bgMusic.loop = true;
        bgMusic.volume = 0.3;
        
        useAudio.getState().setBackgroundMusic(bgMusic);
        useAudio.getState().setHitSound(hitSound);
        useAudio.getState().setSuccessSound(successSound);
      } catch (error) {
        console.log("Audio initialization failed:", error);
      }
    };
    
    initAudio();
  }, []);

  // Handle screen transitions
  useEffect(() => {
    if (phase === 'playing' && currentScreen !== 'battle') {
      setCurrentScreen('battle');
    } else if (phase === 'ended' && battleResult) {
      setCurrentScreen('result');
    }
  }, [phase, battleResult, currentScreen]);

  const handleScreenChange = (screen: GameScreen) => {
    setCurrentScreen(screen);
  };

  return (
    <div style={{ 
      width: '100vw', 
      height: '100vh', 
      position: 'relative', 
      overflow: 'hidden',
      backgroundColor: '#0a0a0a'
    }}>
      {currentScreen === 'menu' && (
        <MainMenu onNavigate={handleScreenChange} />
      )}
      
      {currentScreen === 'collection' && (
        <CardCollection onNavigate={handleScreenChange} />
      )}
      
      {currentScreen === 'battle' && (
        <Suspense fallback={
          <div className="flex items-center justify-center w-full h-full bg-black text-white">
            <div>Loading Battle...</div>
          </div>
        }>
          <BattleScreen onNavigate={handleScreenChange} />
        </Suspense>
      )}
      
      {currentScreen === 'result' && (
        <ResultScreen onNavigate={handleScreenChange} />
      )}
    </div>
  );
}

export default App;
