import { useBattle } from './stores/useBattle';
import { villains, Character } from '../data/characters';

// AI difficulty levels
type AIDifficulty = 'easy' | 'medium' | 'hard';

interface AIState {
  lastDeployTime: number;
  difficulty: AIDifficulty;
  strategy: 'random' | 'balanced' | 'aggressive' | 'defensive' | 'counter' | 'rush';
  currentPlan: Character[];
  energySaved: number;
  lastPlayerAction: number;
  adaptiveTimer: number;
}

let aiState: AIState = {
  lastDeployTime: Date.now(),
  difficulty: 'medium',
  strategy: 'balanced',
  currentPlan: [],
  energySaved: 0,
  lastPlayerAction: Date.now(),
  adaptiveTimer: 0
};

// Main AI update function
export const updateAI = () => {
  const { 
    currentEnergy, 
    deployCharacter, 
    deployedCharacters, 
    towers, 
    timeRemaining,
    battleResult 
  } = useBattle.getState();
  
  // Don't run AI if battle is over
  if (battleResult) return;
  
  const now = Date.now();
  const timeSinceLastDeploy = (now - aiState.lastDeployTime) / 1000;
  
  // AI deployment frequency based on difficulty and adaptive behavior
  let deployInterval = aiState.difficulty === 'easy' ? 6 : aiState.difficulty === 'medium' ? 4 : 2.5;
  
  // Hard AI adapts to player actions
  if (aiState.difficulty === 'hard') {
    const timeSincePlayerAction = (now - aiState.lastPlayerAction) / 1000;
    if (timeSincePlayerAction < 5) {
      deployInterval *= 0.8; // React faster to recent player actions
    }
    
    // Energy management - save energy for combos on hard
    if (currentEnergy >= 8 && aiState.energySaved < 2) {
      deployInterval *= 1.5; // Wait to build up energy for powerful combos
      aiState.energySaved++;
    }
    
    // Reset energy saving if energy drops significantly (combo was used)
    if (currentEnergy < 4) {
      aiState.energySaved = 0;
    }
  }
  
  // Only try to deploy every X seconds
  if (timeSinceLastDeploy < deployInterval) return;
  
  // Update strategy based on battle state
  updateAIStrategy();
  
  // Try to deploy a character
  const characterToDeploy = selectCharacterToDeploy(currentEnergy);
  if (characterToDeploy) {
    const position = selectDeploymentPosition(characterToDeploy);
    deployCharacter(characterToDeploy, position, 'villain');
    aiState.lastDeployTime = now;
    
    // Reset energy saving counter when spending high energy for combos
    if (characterToDeploy.cost >= 6) {
      aiState.energySaved = 0;
    }
  }
};

// Update AI strategy based on current battle state
const updateAIStrategy = () => {
  const { deployedCharacters, towers, timeRemaining, currentEnergy } = useBattle.getState();
  
  const heroCharacters = deployedCharacters.filter(c => c.team === 'hero');
  const villainCharacters = deployedCharacters.filter(c => c.team === 'villain');
  const heroTower = towers.find(t => t.id === 'hero-main');
  const villainTower = towers.find(t => t.id === 'villain-main');
  
  const heroCount = heroCharacters.length;
  const villainCount = villainCharacters.length;
  const hpRatio = villainTower && heroTower ? villainTower.hp / heroTower.hp : 1;
  
  // Advanced strategy selection based on difficulty
  if (aiState.difficulty === 'hard') {
    // Hard AI uses complex strategy selection
    if (timeRemaining < 30) {
      aiState.strategy = 'rush'; // Final desperate push
    } else if (timeRemaining < 60) {
      aiState.strategy = 'aggressive'; // Overtime pressure
    } else if (hpRatio < 0.5) {
      aiState.strategy = 'rush'; // Desperate when losing badly
    } else if (hpRatio < 0.7) {
      aiState.strategy = 'aggressive'; // Push when behind
    } else if (heroCount > villainCount + 2) {
      aiState.strategy = 'counter'; // Counter-attack when outnumbered
    } else if (currentEnergy >= 8) {
      aiState.strategy = 'aggressive'; // Use high energy for push
    } else {
      aiState.strategy = 'balanced';
    }
  } else if (aiState.difficulty === 'medium') {
    // Medium AI uses basic strategy
    if (timeRemaining < 60) {
      aiState.strategy = 'aggressive';
    } else if (hpRatio < 0.7) {
      aiState.strategy = 'defensive';
    } else if (heroCount > villainCount + 2) {
      aiState.strategy = 'defensive';
    } else {
      aiState.strategy = 'balanced';
    }
  } else {
    // Easy AI uses random strategy mostly
    aiState.strategy = Math.random() < 0.7 ? 'random' : 'balanced';
  }
};

// Select which character to deploy based on strategy and available energy
const selectCharacterToDeploy = (availableEnergy: number): Character | null => {
  const availableVillains = villains.filter(v => v.cost <= availableEnergy);
  if (availableVillains.length === 0) return null;
  
  // Strategy-based character selection
  switch (aiState.strategy) {
    case 'aggressive':
      return selectAggressiveCharacter(availableVillains);
    case 'defensive':
      return selectDefensiveCharacter(availableVillains);
    case 'balanced':
      return selectBalancedCharacter(availableVillains);
    case 'counter':
      return selectCounterCharacter(availableVillains);
    case 'rush':
      return selectRushCharacter(availableVillains);
    case 'random':
    default:
      return availableVillains[Math.floor(Math.random() * availableVillains.length)];
  }
};

// Character selection strategies
const selectAggressiveCharacter = (available: Character[]): Character => {
  // Prefer high damage, fast characters
  const aggressive = available
    .filter(c => c.damage >= 150 || c.speed >= 1.5)
    .sort((a, b) => (b.damage + b.speed * 50) - (a.damage + a.speed * 50));
  
  return aggressive[0] || available[Math.floor(Math.random() * available.length)];
};

const selectDefensiveCharacter = (available: Character[]): Character => {
  // Prefer high HP, tanky characters
  const defensive = available
    .filter(c => c.hp >= 1500 || c.range === 'long')
    .sort((a, b) => (b.hp + (b.range === 'long' ? 500 : 0)) - (a.hp + (a.range === 'long' ? 500 : 0)));
  
  return defensive[0] || available[Math.floor(Math.random() * available.length)];
};

const selectBalancedCharacter = (available: Character[]): Character => {
  const { deployedCharacters } = useBattle.getState();
  const villainCharacters = deployedCharacters.filter(c => c.team === 'villain');
  
  // Count current unit types
  const tankCount = villainCharacters.filter(c => c.character.hp >= 2000).length;
  const rangedCount = villainCharacters.filter(c => c.character.range === 'long').length;
  const meleeCount = villainCharacters.filter(c => c.character.range === 'short').length;
  
  // Balance the composition
  if (tankCount === 0 && available.some(c => c.hp >= 2000)) {
    return available.filter(c => c.hp >= 2000)[0];
  } else if (rangedCount < meleeCount && available.some(c => c.range === 'long')) {
    return available.filter(c => c.range === 'long')[0];
  } else {
    return available[Math.floor(Math.random() * available.length)];
  }
};

// Select deployment position based on strategy and character type
const selectDeploymentPosition = (character: Character): [number, number, number] => {
  const { deployedCharacters, towers } = useBattle.getState();
  
  // Get lane occupancy
  const leftLane = deployedCharacters.filter(c => c.position[0] < -3);
  const centerLane = deployedCharacters.filter(c => c.position[0] >= -3 && c.position[0] <= 3);
  const rightLane = deployedCharacters.filter(c => c.position[0] > 3);
  
  let targetX = 0;
  
  // Advanced positioning based on difficulty and strategy
  if (aiState.difficulty === 'hard') {
    // Hard AI uses tactical positioning
    const heroSideTowers = towers.filter(t => t.type === 'hero' && t.variant === 'side' && t.hp > 0);
    
    if (aiState.strategy === 'rush' || aiState.strategy === 'aggressive') {
      // Target weakest side tower or center if main tower is exposed
      if (heroSideTowers.length === 0) {
        targetX = 0; // Go for main tower
      } else {
        const leftTower = towers.find(t => t.id === 'hero-left');
        const rightTower = towers.find(t => t.id === 'hero-right');
        targetX = (leftTower && leftTower.hp < (rightTower?.hp || 9999)) ? -6 : 6;
      }
    } else if (character.range === 'long') {
      // Place ranged units in supporting positions
      targetX = centerLane.length < 2 ? 0 : (leftLane.length < rightLane.length ? -6 : 6);
    } else {
      // Tank units go to most threatened lane
      const heroCount = { left: leftLane.filter(c => c.team === 'hero').length, 
                         center: centerLane.filter(c => c.team === 'hero').length,
                         right: rightLane.filter(c => c.team === 'hero').length };
      const maxThreat = Math.max(heroCount.left, heroCount.center, heroCount.right);
      if (heroCount.left === maxThreat) targetX = -6;
      else if (heroCount.right === maxThreat) targetX = 6;
      else targetX = 0;
    }
  } else {
    // Medium/Easy AI uses simpler positioning
    const minOccupancy = Math.min(leftLane.length, centerLane.length, rightLane.length);
    
    if (leftLane.length === minOccupancy && Math.random() > 0.5) {
      targetX = -6;
    } else if (rightLane.length === minOccupancy && Math.random() > 0.5) {
      targetX = 6;
    } else {
      targetX = 0;
    }
  }
  
  // Add controlled randomness based on difficulty
  const randomness = aiState.difficulty === 'hard' ? 1 : aiState.difficulty === 'medium' ? 2 : 4;
  targetX += (Math.random() - 0.5) * randomness;
  targetX = Math.max(-8, Math.min(8, targetX));
  
  // Deploy in AI's area with strategic depth
  let deployZ = -8;
  if (aiState.difficulty === 'hard' && character.range === 'long') {
    deployZ = -7; // Keep ranged units slightly back
  } else if (aiState.strategy === 'rush') {
    deployZ = -6; // More aggressive positioning for rush
  }
  deployZ += Math.random() * 1;
  
  return [targetX, 0, deployZ];
};


// Reset AI state for new battle
export const resetAI = () => {
  aiState = {
    lastDeployTime: Date.now(),
    difficulty: 'medium',
    strategy: 'balanced',
    currentPlan: [],
    energySaved: 0,
    lastPlayerAction: Date.now(),
    adaptiveTimer: 0
  };
};

// Additional character selection strategies for hard AI
const selectCounterCharacter = (available: Character[]): Character => {
  const { deployedCharacters } = useBattle.getState();
  const heroCharacters = deployedCharacters.filter(c => c.team === 'hero');
  
  // Counter enemy composition
  const heroTypes = {
    tanks: heroCharacters.filter(c => c.character.hp >= 2000).length,
    ranged: heroCharacters.filter(c => c.character.range === 'long').length,
    fast: heroCharacters.filter(c => c.character.speed >= 1.5).length
  };
  
  // Select counter based on dominant enemy type
  if (heroTypes.tanks > 0) {
    // Counter tanks with high DPS
    const antiTank = available.filter(c => c.damage >= 200).sort((a, b) => b.damage - a.damage);
    if (antiTank.length > 0) return antiTank[0];
  }
  
  if (heroTypes.ranged > heroTypes.fast) {
    // Counter ranged with fast units
    const fastUnits = available.filter(c => c.speed >= 1.5).sort((a, b) => b.speed - a.speed);
    if (fastUnits.length > 0) return fastUnits[0];
  }
  
  return available[Math.floor(Math.random() * available.length)];
};

const selectRushCharacter = (available: Character[]): Character => {
  // Prefer fast, high-damage units for rush
  const rushUnits = available
    .filter(c => c.speed >= 1.2 && c.damage >= 120)
    .sort((a, b) => (b.damage * b.speed) - (a.damage * a.speed));
  
  return rushUnits[0] || available[Math.floor(Math.random() * available.length)];
};

// Track player actions for adaptive AI
export const notifyPlayerAction = () => {
  aiState.lastPlayerAction = Date.now();
  
  // Reset adaptive timer for more responsive behavior
  aiState.adaptiveTimer = 0;
};

// Get AI statistics for debugging
export const getAIStats = () => {
  const now = Date.now();
  return {
    difficulty: aiState.difficulty,
    strategy: aiState.strategy,
    lastDeployTime: aiState.lastDeployTime,
    timeSinceLastDeploy: (now - aiState.lastDeployTime) / 1000,
    energySaved: aiState.energySaved,
    adaptiveTimer: aiState.adaptiveTimer,
    timeSincePlayerAction: (now - aiState.lastPlayerAction) / 1000
  };
};

// Get current AI difficulty for UI
export const getCurrentDifficulty = (): AIDifficulty => {
  return aiState.difficulty;
};

// Set AI difficulty with immediate strategy adjustment
export const setAIDifficulty = (difficulty: AIDifficulty) => {
  aiState.difficulty = difficulty;
  aiState.energySaved = 0;
  aiState.adaptiveTimer = 0;
  
  // Adjust initial strategy based on difficulty
  if (difficulty === 'hard') {
    aiState.strategy = 'balanced';
  } else if (difficulty === 'medium') {
    aiState.strategy = 'balanced';
  } else {
    aiState.strategy = 'random';
  }
};
