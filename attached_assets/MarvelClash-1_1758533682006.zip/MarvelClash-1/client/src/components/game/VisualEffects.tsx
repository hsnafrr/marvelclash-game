import { useFrame } from '@react-three/fiber';
import { useRef, useMemo } from 'react';
import * as THREE from 'three';

interface VisualEffectsProps {
  characterName: string;
  abilityActive: boolean;
  position: [number, number, number];
  team: 'hero' | 'villain';
}

export function VisualEffects({ characterName, abilityActive, position, team }: VisualEffectsProps) {
  const groupRef = useRef<THREE.Group>(null);
  const timeRef = useRef(0);

  useFrame((state, delta) => {
    timeRef.current += delta;
    if (!groupRef.current) return;

    // Update effects based on character
    switch (characterName) {
      case 'Iron Man':
        updateUnibeamEffect(groupRef.current, timeRef.current, abilityActive, team);
        break;
      case 'Thor':
        updateLightningStormEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Hulk':
        updateRageModeEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Doctor Strange':
        updateTimeFreezeEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Scarlet Witch':
        updateRealityWarpEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Captain Marvel':
        updateSupernovaEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Thanos':
        updateSnapEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Dormammu':
        updateDarkInfernoEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Magneto':
        updateMagneticStormEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Hela':
        updateUndeadSummonEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Vision':
        updatePhaseShiftEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Venom':
        updateSymbioteLeapEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Captain America':
        updateShieldThrowEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Black Widow':
        updateTaserShockEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Hawkeye':
        updateExplosiveArrowEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Spider-Man':
        updateWebShotEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Black Panther':
        updateKineticChargeEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Ant-Man':
        updateShrinkSwarmEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Falcon':
        updateDroneStrikeEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Winter Soldier':
        updateArmPunchEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Loki':
        updateIllusionCloneEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Ultron':
        updateDroneArmyEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Red Skull':
        updateHydraRallyEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Green Goblin':
        updateGliderRushEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Mysterio':
        updateSmokeScreenEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Kingpin':
        updateBodySlamEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Killmonger':
        updateTacticalRushEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Ronan':
        updateOrbBeamEffect(groupRef.current, timeRef.current, abilityActive);
        break;
      case 'Yellowjacket':
        updateStingStrikeEffect(groupRef.current, timeRef.current, abilityActive);
        break;
    }
  });

  const effectGeometry = useMemo(() => {
    return getEffectGeometry(characterName);
  }, [characterName]);

  return (
    <group ref={groupRef} position={position}>
      {abilityActive && effectGeometry}
    </group>
  );
}

// Effect geometry generators
function getEffectGeometry(characterName: string) {
  switch (characterName) {
    case 'Iron Man':
      return <UnibeamGeometry />;
    case 'Thor':
      return <LightningStormGeometry />;
    case 'Hulk':
      return <RageModeGeometry />;
    case 'Doctor Strange':
      return <TimeFreezeGeometry />;
    case 'Scarlet Witch':
      return <RealityWarpGeometry />;
    case 'Captain Marvel':
      return <SupernovaGeometry />;
    case 'Thanos':
      return <SnapGeometry />;
    case 'Dormammu':
      return <DarkInfernoGeometry />;
    case 'Magneto':
      return <MagneticStormGeometry />;
    case 'Hela':
      return <UndeadSummonGeometry />;
    case 'Vision':
      return <PhaseShiftGeometry />;
    case 'Venom':
      return <SymbioteLeapGeometry />;
    case 'Captain America':
      return <ShieldThrowGeometry />;
    case 'Black Widow':
      return <TaserShockGeometry />;
    case 'Hawkeye':
      return <ExplosiveArrowGeometry />;
    case 'Spider-Man':
      return <WebShotGeometry />;
    case 'Black Panther':
      return <KineticChargeGeometry />;
    case 'Ant-Man':
      return <ShrinkSwarmGeometry />;
    case 'Falcon':
      return <DroneStrikeGeometry />;
    case 'Winter Soldier':
      return <ArmPunchGeometry />;
    case 'Loki':
      return <IllusionCloneGeometry />;
    case 'Ultron':
      return <DroneArmyGeometry />;
    case 'Red Skull':
      return <HydraRallyGeometry />;
    case 'Green Goblin':
      return <GliderRushGeometry />;
    case 'Mysterio':
      return <SmokeScreenGeometry />;
    case 'Kingpin':
      return <BodySlamGeometry />;
    case 'Killmonger':
      return <TacticalRushGeometry />;
    case 'Ronan':
      return <OrbBeamGeometry />;
    case 'Yellowjacket':
      return <StingStrikeGeometry />;
    default:
      return <DefaultAbilityGeometry />;
  }
}

// Individual effect components
function UnibeamGeometry() {
  return (
    <group>
      {/* Main beam */}
      <mesh position={[0, 0, -10]} rotation={[Math.PI/2, 0, 0]}>
        <cylinderGeometry args={[0.2, 0.2, 20, 8]} />
        <meshBasicMaterial color="#FFD700" transparent opacity={0.8} />
      </mesh>
      {/* Energy core */}
      <mesh>
        <sphereGeometry args={[0.3]} />
        <meshBasicMaterial color="#FFFFFF" />
      </mesh>
      {/* Beam particles */}
      {Array.from({length: 12}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 12) * Math.PI * 2) * 0.4,
            0,
            Math.sin((i / 12) * Math.PI * 2) * 0.4 - 5
          ]}
        >
          <sphereGeometry args={[0.1]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
      ))}
    </group>
  );
}

function LightningStormGeometry() {
  return (
    <group>
      {/* Lightning bolts */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 2,
            2,
            Math.sin((i / 6) * Math.PI * 2) * 2
          ]}
          rotation={[0, 0, Math.PI/4]}
        >
          <boxGeometry args={[0.1, 3, 0.1]} />
          <meshBasicMaterial color="#87CEEB" />
        </mesh>
      ))}
      {/* Electric field */}
      <mesh position={[0, 0, 0]} rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[3, 0.1, 8, 32]} />
        <meshBasicMaterial color="#1E90FF" transparent opacity={0.6} />
      </mesh>
    </group>
  );
}

function RageModeGeometry() {
  return (
    <group>
      {/* Rage aura */}
      <mesh>
        <sphereGeometry args={[2, 16, 16]} />
        <meshBasicMaterial color="#32CD32" transparent opacity={0.3} />
      </mesh>
      {/* Power spikes */}
      {Array.from({length: 8}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 8) * Math.PI * 2) * 1.8,
            1,
            Math.sin((i / 8) * Math.PI * 2) * 1.8
          ]}
        >
          <coneGeometry args={[0.2, 0.8, 6]} />
          <meshBasicMaterial color="#00FF00" />
        </mesh>
      ))}
    </group>
  );
}

function TimeFreezeGeometry() {
  return (
    <group>
      {/* Magical circles */}
      <mesh position={[0, 1, 0]} rotation={[0, 0, 0]}>
        <torusGeometry args={[2, 0.05, 8, 32]} />
        <meshBasicMaterial color="#9932CC" />
      </mesh>
      <mesh position={[0, 0.5, 0]} rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[1.5, 0.03, 8, 32]} />
        <meshBasicMaterial color="#DDA0DD" />
      </mesh>
      {/* Mystic symbols */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 2.5,
            0.8,
            Math.sin((i / 6) * Math.PI * 2) * 2.5
          ]}
        >
          <sphereGeometry args={[0.1]} />
          <meshBasicMaterial color="#800080" />
        </mesh>
      ))}
    </group>
  );
}

function RealityWarpGeometry() {
  const chaosPositions = useMemo(() => 
    Array.from({length: 10}).map(() => [
      (Math.random() - 0.5) * 6,
      Math.random() * 3,
      (Math.random() - 0.5) * 6
    ]), []
  );

  return (
    <group>
      {/* Reality distortion */}
      <mesh>
        <sphereGeometry args={[3, 32, 32]} />
        <meshBasicMaterial color="#DC143C" transparent opacity={0.2} />
      </mesh>
      {/* Chaos energy */}
      {chaosPositions.map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]}>
          <boxGeometry args={[0.2, 0.2, 0.2]} />
          <meshBasicMaterial color="#FF1493" />
        </mesh>
      ))}
    </group>
  );
}

function SupernovaGeometry() {
  return (
    <group>
      {/* Explosion core */}
      <mesh>
        <sphereGeometry args={[1.5, 16, 16]} />
        <meshBasicMaterial color="#FFD700" transparent opacity={0.8} />
      </mesh>
      {/* Energy waves */}
      {Array.from({length: 3}).map((_, i) => (
        <mesh key={i} position={[0, 0.2 * i, 0]} rotation={[Math.PI/2, 0, 0]}>
          <torusGeometry args={[2 + i, 0.1, 8, 32]} />
          <meshBasicMaterial color="#FF6347" transparent opacity={0.6 - i * 0.2} />
        </mesh>
      ))}
    </group>
  );
}

function SnapGeometry() {
  return (
    <group>
      {/* Infinity stones effect */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 1,
            0.5,
            Math.sin((i / 6) * Math.PI * 2) * 1
          ]}
        >
          <sphereGeometry args={[0.2]} />
          <meshBasicMaterial color={getStoneColor(i)} />
        </mesh>
      ))}
      {/* Reality crack */}
      <mesh rotation={[0, 0, Math.PI/4]}>
        <boxGeometry args={[6, 0.1, 0.1]} />
        <meshBasicMaterial color="#800080" transparent opacity={0.7} />
      </mesh>
    </group>
  );
}

function DarkInfernoGeometry() {
  return (
    <group>
      {/* Fire base */}
      <mesh position={[0, -0.5, 0]}>
        <cylinderGeometry args={[2, 3, 1, 8]} />
        <meshBasicMaterial color="#FF4500" transparent opacity={0.7} />
      </mesh>
      {/* Fire pillars */}
      {Array.from({length: 5}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 5) * Math.PI * 2) * 2.5,
            1.5,
            Math.sin((i / 5) * Math.PI * 2) * 2.5
          ]}
        >
          <cylinderGeometry args={[0.3, 0.5, 3, 6]} />
          <meshBasicMaterial color="#8B0000" />
        </mesh>
      ))}
    </group>
  );
}

function MagneticStormGeometry() {
  return (
    <group>
      {/* Magnetic field lines */}
      {Array.from({length: 8}).map((_, i) => (
        <mesh
          key={i}
          position={[0, 0, 0]}
          rotation={[0, (i / 8) * Math.PI * 2, Math.PI/4]}
        >
          <torusGeometry args={[2, 0.05, 8, 16]} />
          <meshBasicMaterial color="#4B0082" />
        </mesh>
      ))}
      {/* Metal particles */}
      {Array.from({length: 12}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 12) * Math.PI * 2) * 3,
            Math.sin(i * 0.5) * 2,
            Math.sin((i / 12) * Math.PI * 2) * 3
          ]}
        >
          <boxGeometry args={[0.2, 0.2, 0.2]} />
          <meshBasicMaterial color="#696969" />
        </mesh>
      ))}
    </group>
  );
}

function UndeadSummonGeometry() {
  return (
    <group>
      {/* Necromantic circle */}
      <mesh position={[0, 0, 0]} rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[2.5, 0.1, 8, 32]} />
        <meshBasicMaterial color="#000000" />
      </mesh>
      {/* Dark energy */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 2,
            0.5,
            Math.sin((i / 6) * Math.PI * 2) * 2
          ]}
        >
          <cylinderGeometry args={[0.1, 0.2, 1, 6]} />
          <meshBasicMaterial color="#4B0082" />
        </mesh>
      ))}
    </group>
  );
}

function PhaseShiftGeometry() {
  return (
    <group>
      {/* Phasing effect */}
      <mesh>
        <sphereGeometry args={[1.5, 16, 16]} />
        <meshBasicMaterial color="#FFD700" transparent opacity={0.3} />
      </mesh>
      {/* Density waves */}
      {Array.from({length: 4}).map((_, i) => (
        <mesh key={i} rotation={[Math.PI/2, 0, 0]}>
          <torusGeometry args={[1 + i * 0.3, 0.05, 8, 32]} />
          <meshBasicMaterial color="#FF6347" transparent opacity={0.6 - i * 0.15} />
        </mesh>
      ))}
    </group>
  );
}

function SymbioteLeapGeometry() {
  return (
    <group>
      {/* Symbiote tendrils */}
      {Array.from({length: 8}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 8) * Math.PI * 2) * 1.5,
            1,
            Math.sin((i / 8) * Math.PI * 2) * 1.5
          ]}
          rotation={[0, (i / 8) * Math.PI * 2, Math.PI/6]}
        >
          <cylinderGeometry args={[0.1, 0.05, 2, 8]} />
          <meshBasicMaterial color="#000000" />
        </mesh>
      ))}
      {/* Dark energy core */}
      <mesh>
        <sphereGeometry args={[0.8]} />
        <meshBasicMaterial color="#4B0082" transparent opacity={0.7} />
      </mesh>
    </group>
  );
}

// Additional character geometry components
function ShieldThrowGeometry() {
  return (
    <group>
      {/* Shield spinning effect */}
      <mesh>
        <cylinderGeometry args={[1, 1, 0.1, 16]} />
        <meshBasicMaterial color="#4169E1" transparent opacity={0.8} />
      </mesh>
      {/* Star pattern */}
      {Array.from({length: 5}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/5) * Math.PI * 2) * 0.7, 0, Math.sin((i/5) * Math.PI * 2) * 0.7]}>
          <coneGeometry args={[0.1, 0.3, 4]} />
          <meshBasicMaterial color="#FFFFFF" />
        </mesh>
      ))}
    </group>
  );
}

function TaserShockGeometry() {
  return (
    <group>
      {/* Electric sparks */}
      {Array.from({length: 8}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/8) * Math.PI * 2) * 1.2, Math.sin(i) * 0.5, Math.sin((i/8) * Math.PI * 2) * 1.2]}>
          <boxGeometry args={[0.05, 0.8, 0.05]} />
          <meshBasicMaterial color="#8A2BE2" />
        </mesh>
      ))}
      {/* Central spark */}
      <mesh>
        <sphereGeometry args={[0.3]} />
        <meshBasicMaterial color="#FFFFFF" />
      </mesh>
    </group>
  );
}

function ExplosiveArrowGeometry() {
  return (
    <group>
      {/* Explosion effect */}
      <mesh>
        <sphereGeometry args={[2]} />
        <meshBasicMaterial color="#FF4500" transparent opacity={0.6} />
      </mesh>
      {/* Shrapnel */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/6) * Math.PI * 2) * 2.5, 0.5, Math.sin((i/6) * Math.PI * 2) * 2.5]}>
          <boxGeometry args={[0.1, 0.1, 0.4]} />
          <meshBasicMaterial color="#8B4513" />
        </mesh>
      ))}
    </group>
  );
}

function WebShotGeometry() {
  return (
    <group>
      {/* Web pattern */}
      {Array.from({length: 8}).map((_, i) => (
        <mesh key={i} rotation={[0, (i/8) * Math.PI * 2, 0]}>
          <cylinderGeometry args={[0.02, 0.02, 3, 8]} />
          <meshBasicMaterial color="#C0C0C0" />
        </mesh>
      ))}
      {/* Web center */}
      <mesh>
        <sphereGeometry args={[0.2]} />
        <meshBasicMaterial color="#FFFFFF" />
      </mesh>
    </group>
  );
}

function KineticChargeGeometry() {
  return (
    <group>
      {/* Energy buildup */}
      <mesh>
        <sphereGeometry args={[1.5]} />
        <meshBasicMaterial color="#9400D3" transparent opacity={0.5} />
      </mesh>
      {/* Kinetic lines */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh key={i} position={[0, 0, 0]} rotation={[(i/6) * Math.PI, (i/6) * Math.PI * 2, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 2, 8]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
      ))}
    </group>
  );
}

function ShrinkSwarmGeometry() {
  const swarmPositions = useMemo(() => 
    Array.from({length: 12}).map(() => [
      (Math.random() - 0.5) * 4,
      Math.random() * 2,
      (Math.random() - 0.5) * 4
    ]), []
  );
  
  return (
    <group>
      {/* Mini ant-men */}
      {swarmPositions.map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]}>
          <sphereGeometry args={[0.1]} />
          <meshBasicMaterial color="#FF0000" />
        </mesh>
      ))}
    </group>
  );
}

function DroneStrikeGeometry() {
  return (
    <group>
      {/* Drone formation */}
      {Array.from({length: 4}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/4) * Math.PI * 2) * 2, 2, Math.sin((i/4) * Math.PI * 2) * 2]}>
          <boxGeometry args={[0.3, 0.1, 0.3]} />
          <meshBasicMaterial color="#4169E1" />
        </mesh>
      ))}
      {/* Targeting beams */}
      {Array.from({length: 4}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/4) * Math.PI * 2), 1, Math.sin((i/4) * Math.PI * 2)]} rotation={[Math.PI/2, 0, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 2, 8]} />
          <meshBasicMaterial color="#FF0000" transparent opacity={0.7} />
        </mesh>
      ))}
    </group>
  );
}

function ArmPunchGeometry() {
  return (
    <group>
      {/* Impact shockwave */}
      <mesh rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[2, 0.2, 8, 32]} />
        <meshBasicMaterial color="#708090" transparent opacity={0.7} />
      </mesh>
      {/* Metal sparks */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/6) * Math.PI * 2) * 2.5, 0.5, Math.sin((i/6) * Math.PI * 2) * 2.5]}>
          <sphereGeometry args={[0.1]} />
          <meshBasicMaterial color="#C0C0C0" />
        </mesh>
      ))}
    </group>
  );
}

function IllusionCloneGeometry() {
  return (
    <group>
      {/* Illusion shimmer */}
      <mesh>
        <sphereGeometry args={[2, 16, 16]} />
        <meshBasicMaterial color="#228B22" transparent opacity={0.3} />
      </mesh>
      {/* Clone outlines */}
      {Array.from({length: 3}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/3) * Math.PI * 2) * 1.5, 0, Math.sin((i/3) * Math.PI * 2) * 1.5]}>
          <boxGeometry args={[0.5, 1.5, 0.1]} />
          <meshBasicMaterial color="#32CD32" transparent opacity={0.5} />
        </mesh>
      ))}
    </group>
  );
}

function DroneArmyGeometry() {
  return (
    <group>
      {/* Attack drones */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/6) * Math.PI * 2) * 2.5, 1 + Math.sin(i) * 0.5, Math.sin((i/6) * Math.PI * 2) * 2.5]}>
          <boxGeometry args={[0.4, 0.2, 0.4]} />
          <meshBasicMaterial color="#FF0000" />
        </mesh>
      ))}
      {/* Energy connections */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh key={i} rotation={[0, (i/6) * Math.PI * 2, 0]}>
          <cylinderGeometry args={[0.02, 0.02, 2.5, 8]} />
          <meshBasicMaterial color="#0000FF" transparent opacity={0.6} />
        </mesh>
      ))}
    </group>
  );
}

function HydraRallyGeometry() {
  return (
    <group>
      {/* Hydra symbol */}
      <mesh>
        <cylinderGeometry args={[1.5, 1.5, 0.1, 6]} />
        <meshBasicMaterial color="#DC143C" />
      </mesh>
      {/* Rally aura */}
      <mesh>
        <torusGeometry args={[3, 0.1, 8, 32]} />
        <meshBasicMaterial color="#8B0000" transparent opacity={0.5} />
      </mesh>
    </group>
  );
}

function GliderRushGeometry() {
  return (
    <group>
      {/* Glider trail */}
      <mesh position={[0, 0, -2]} rotation={[Math.PI/2, 0, 0]}>
        <cylinderGeometry args={[0.1, 0.3, 4, 8]} />
        <meshBasicMaterial color="#228B22" transparent opacity={0.7} />
      </mesh>
      {/* Speed lines */}
      {Array.from({length: 5}).map((_, i) => (
        <mesh key={i} position={[0, 0, -i]} rotation={[Math.PI/2, 0, 0]}>
          <boxGeometry args={[0.1, 0.5, 0.1]} />
          <meshBasicMaterial color="#FFFF00" />
        </mesh>
      ))}
    </group>
  );
}

function SmokeScreenGeometry() {
  const smokePositions = useMemo(() => 
    Array.from({length: 15}).map(() => [
      (Math.random() - 0.5) * 6,
      Math.random() * 3,
      (Math.random() - 0.5) * 6
    ]), []
  );
  
  return (
    <group>
      {/* Smoke clouds */}
      {smokePositions.map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]}>
          <sphereGeometry args={[0.3 + Math.sin(i) * 0.2]} />
          <meshBasicMaterial color="#9932CC" transparent opacity={0.4} />
        </mesh>
      ))}
    </group>
  );
}

function BodySlamGeometry() {
  return (
    <group>
      {/* Ground crack */}
      <mesh position={[0, -0.5, 0]} rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[3, 0.2, 8, 32]} />
        <meshBasicMaterial color="#8B4513" />
      </mesh>
      {/* Impact force */}
      {Array.from({length: 8}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/8) * Math.PI * 2) * 3.5, 0, Math.sin((i/8) * Math.PI * 2) * 3.5]}>
          <coneGeometry args={[0.2, 1, 6]} />
          <meshBasicMaterial color="#FFFFFF" />
        </mesh>
      ))}
    </group>
  );
}

function TacticalRushGeometry() {
  return (
    <group>
      {/* Speed boost aura */}
      <mesh>
        <sphereGeometry args={[1.8]} />
        <meshBasicMaterial color="#FFD700" transparent opacity={0.4} />
      </mesh>
      {/* Movement trails */}
      {Array.from({length: 4}).map((_, i) => (
        <mesh key={i} position={[0, 0, -i * 0.5]} rotation={[Math.PI/2, 0, 0]}>
          <cylinderGeometry args={[0.1, 0.2, 0.8, 8]} />
          <meshBasicMaterial color="#FF6347" transparent opacity={0.8 - i * 0.2} />
        </mesh>
      ))}
    </group>
  );
}

function OrbBeamGeometry() {
  return (
    <group>
      {/* Power Stone beam */}
      <mesh position={[0, 0, -8]} rotation={[Math.PI/2, 0, 0]}>
        <cylinderGeometry args={[0.3, 0.3, 16, 8]} />
        <meshBasicMaterial color="#4B0082" transparent opacity={0.8} />
      </mesh>
      {/* Orb energy */}
      <mesh>
        <sphereGeometry args={[0.5]} />
        <meshBasicMaterial color="#8A2BE2" />
      </mesh>
    </group>
  );
}

function StingStrikeGeometry() {
  return (
    <group>
      {/* Sting energy */}
      <mesh>
        <coneGeometry args={[0.3, 1.2, 8]} />
        <meshBasicMaterial color="#FFFF00" transparent opacity={0.8} />
      </mesh>
      {/* Energy particles */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh key={i} position={[Math.cos((i/6) * Math.PI * 2) * 0.8, 0.5, Math.sin((i/6) * Math.PI * 2) * 0.8]}>
          <sphereGeometry args={[0.08]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
      ))}
    </group>
  );
}

function DefaultAbilityGeometry() {
  return (
    <group>
      {/* Basic energy effect */}
      <mesh rotation={[Math.PI/2, 0, 0]}>
        <torusGeometry args={[1.2, 0.1, 8, 32]} />
        <meshBasicMaterial color="#FFD700" />
      </mesh>
      {/* Energy particles */}
      {Array.from({length: 6}).map((_, i) => (
        <mesh
          key={i}
          position={[
            Math.cos((i / 6) * Math.PI * 2) * 1.5,
            0.2,
            Math.sin((i / 6) * Math.PI * 2) * 1.5
          ]}
        >
          <sphereGeometry args={[0.1]} />
          <meshBasicMaterial color="#FFFF00" />
        </mesh>
      ))}
    </group>
  );
}

// Effect update functions
function updateUnibeamEffect(group: THREE.Group, time: number, active: boolean, team: 'hero' | 'villain') {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      // Beam pulsing effect
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.8 + Math.sin(time * 10) * 0.2;
      
      // Extend beam forward based on team
      const direction = team === 'hero' ? -1 : 1;
      child.position.z = direction * 10;
    }
  });
}

function updateLightningStormEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      // Lightning flickering
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = Math.random() > 0.3 ? 1 : 0.3;
      
      // Random rotation for chaos
      child.rotation.y = time * 2 + i;
    }
  });
}

function updateRageModeEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      // Pulsing aura
      child.scale.setScalar(1 + Math.sin(time * 5) * 0.3);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.ConeGeometry) {
      // Rotating spikes
      child.rotation.y = time * 3 + i;
      child.scale.y = 1 + Math.sin(time * 8 + i) * 0.5;
    }
  });
}

function updateTimeFreezeEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      // Slow mystical rotation
      child.rotation.z = time * 0.5 + i;
    }
  });
}

function updateRealityWarpEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      // Chaotic movement
      child.position.x += Math.sin(time * 3 + i) * 0.1;
      child.position.y += Math.cos(time * 2 + i) * 0.1;
      child.position.z += Math.sin(time * 4 + i) * 0.1;
      child.rotation.x = time * 2 + i;
      child.rotation.y = time * 3 + i;
    }
  });
}

function updateSupernovaEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      // Pulsing explosion
      child.scale.setScalar(1 + Math.sin(time * 8) * 0.4);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      // Expanding waves
      const scale = 1 + Math.sin(time * 4 + i * 2) * 0.5;
      child.scale.setScalar(scale);
    }
  });
}

function updateSnapEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      // Infinity stones orbiting
      const radius = 1 + Math.sin(time * 2) * 0.3;
      child.position.x = Math.cos(time * 2 + (i / 6) * Math.PI * 2) * radius;
      child.position.z = Math.sin(time * 2 + (i / 6) * Math.PI * 2) * radius;
    }
  });
}

function updateDarkInfernoEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      // Flickering flames
      child.scale.y = 1 + Math.sin(time * 6 + i) * 0.4;
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.7 + Math.sin(time * 8 + i) * 0.3;
    }
  });
}

function updateMagneticStormEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      // Rotating magnetic field lines
      child.rotation.y = time + i * 0.5;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      // Orbiting metal particles
      const radius = 3 + Math.sin(time * 2 + i) * 0.5;
      child.position.x = Math.cos(time * 3 + (i / 12) * Math.PI * 2) * radius;
      child.position.z = Math.sin(time * 3 + (i / 12) * Math.PI * 2) * radius;
    }
  });
}

function updateUndeadSummonEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      // Dark circle rotation
      child.rotation.z = -time * 0.8;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      // Rising dark energy
      child.scale.y = 1 + Math.sin(time * 4 + i * 2) * 0.6;
    }
  });
}

function updatePhaseShiftEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      // Phasing opacity
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.3 + Math.sin(time * 6 + i) * 0.3;
      
      if (child.geometry instanceof THREE.TorusGeometry) {
        // Density wave expansion
        child.scale.setScalar(1 + Math.sin(time * 3 + i) * 0.2);
      }
    }
  });
}

function updateSymbioteLeapEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      // Writhing tendrils
      child.rotation.z = Math.sin(time * 4 + i) * 0.3;
      child.scale.y = 1 + Math.sin(time * 6 + i * 2) * 0.4;
    }
  });
}

// Helper function for infinity stone colors
function getStoneColor(index: number): string {
  const colors = ['#800080', '#0000FF', '#FF0000', '#FFD700', '#FFA500', '#00FF00'];
  return colors[index] || '#FFD700';
}

// Additional update functions for new characters
function updateShieldThrowEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      child.rotation.y = time * 5;
    }
  });
}

function updateTaserShockEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = Math.random() > 0.3 ? 1 : 0.2;
    }
  });
}

function updateExplosiveArrowEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 8) * 0.3);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      child.position.x += Math.sin(time + i) * 0.1;
      child.position.z += Math.cos(time + i) * 0.1;
    }
  });
}

function updateWebShotEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      child.rotation.y = time * 2 + i;
      child.scale.y = 1 + Math.sin(time * 4 + i) * 0.2;
    }
  });
}

function updateKineticChargeEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 6) * 0.4);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      child.rotation.x = time * 3 + i;
      child.scale.setScalar(1 + Math.sin(time * 8 + i) * 0.2);
    }
  });
}

function updateShrinkSwarmEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      const radius = 2 + Math.sin(time * 2 + i) * 1;
      child.position.x = Math.cos(time * 3 + (i/12) * Math.PI * 2) * radius;
      child.position.z = Math.sin(time * 3 + (i/12) * Math.PI * 2) * radius;
      child.position.y = 0.5 + Math.sin(time * 4 + i) * 0.3;
    }
  });
}

function updateDroneStrikeEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      child.position.y = 2 + Math.sin(time * 2 + i) * 0.5;
      child.rotation.y = time + i;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.7 + Math.sin(time * 10) * 0.3;
    }
  });
}

function updateArmPunchEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 10) * 0.5);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      child.position.y += 0.1;
      child.scale.setScalar(Math.max(0.1, 1 - time * 2));
    }
  });
}

function updateIllusionCloneEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.3 + Math.sin(time * 4) * 0.2;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.5 + Math.sin(time * 6 + i) * 0.3;
      child.rotation.y = time + i;
    }
  });
}

function updateDroneArmyEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      child.position.y = 1 + Math.sin(time * 2 + i) * 0.5;
      child.rotation.z = Math.sin(time * 3 + i) * 0.2;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.6 + Math.sin(time * 8 + i) * 0.4;
    }
  });
}

function updateHydraRallyEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      child.rotation.y = time * 2;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 4) * 0.3);
    }
  });
}

function updateGliderRushEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      child.position.z = -2 - time * 2;
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.7 + Math.sin(time * 12) * 0.3;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.BoxGeometry) {
      child.position.z = -i - time * 3;
    }
  });
}

function updateSmokeScreenEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      child.position.y += Math.sin(time * 2 + i) * 0.05;
      child.rotation.y = time * 0.5 + i;
      child.scale.setScalar(1 + Math.sin(time * 3 + i) * 0.2);
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.4 + Math.sin(time * 4 + i) * 0.2;
    }
  });
}

function updateBodySlamEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.TorusGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 8) * 0.4);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.ConeGeometry) {
      child.position.y = Math.sin(time * 6 + i) * 0.3;
      child.rotation.y = time * 2 + i;
    }
  });
}

function updateTacticalRushEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 5) * 0.3);
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      child.position.z = -i * 0.5 - time * 2;
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = (0.8 - i * 0.2) + Math.sin(time * 8) * 0.2;
    }
  });
}

function updateOrbBeamEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.CylinderGeometry) {
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.8 + Math.sin(time * 10) * 0.2;
      child.scale.x = 1 + Math.sin(time * 8) * 0.2;
      child.scale.z = 1 + Math.sin(time * 8) * 0.2;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      child.scale.setScalar(1 + Math.sin(time * 6) * 0.3);
      child.rotation.y = time * 3;
    }
  });
}

function updateStingStrikeEffect(group: THREE.Group, time: number, active: boolean) {
  if (!active) return;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh && child.geometry instanceof THREE.ConeGeometry) {
      child.scale.y = 1 + Math.sin(time * 8) * 0.5;
      const material = child.material as THREE.MeshBasicMaterial;
      material.opacity = 0.8 + Math.sin(time * 12) * 0.2;
    } else if (child instanceof THREE.Mesh && child.geometry instanceof THREE.SphereGeometry) {
      child.position.y = 0.5 + Math.sin(time * 6 + i * 2) * 0.3;
      child.scale.setScalar(1 + Math.sin(time * 10 + i) * 0.2);
    }
  });
}