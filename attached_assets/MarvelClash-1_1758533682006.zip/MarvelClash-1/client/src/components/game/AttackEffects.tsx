import { useFrame } from '@react-three/fiber';
import { useRef, useEffect } from 'react';
import * as THREE from 'three';

interface AttackEffectsProps {
  characterName: string;
  isAttacking: boolean;
  position: [number, number, number];
  team: 'hero' | 'villain';
  range: 'short' | 'medium' | 'long';
}

export function AttackEffects({ characterName, isAttacking, position, team, range }: AttackEffectsProps) {
  const groupRef = useRef<THREE.Group>(null);
  const timeRef = useRef(0);

  useFrame((state, delta) => {
    timeRef.current += delta;
    if (!groupRef.current || !isAttacking) return;

    // Update attack effects based on character and range
    switch (range) {
      case 'long':
        updateRangedAttackEffects(groupRef.current, timeRef.current, characterName, team);
        break;
      case 'medium':
        updateMediumRangeAttackEffects(groupRef.current, timeRef.current, characterName);
        break;
      case 'short':
        updateMeleeAttackEffects(groupRef.current, timeRef.current, characterName);
        break;
    }
  });

  return (
    <group ref={groupRef} position={position}>
      {isAttacking && getRangedAttackGeometry(characterName, range, team)}
    </group>
  );
}

function getRangedAttackGeometry(characterName: string, range: 'short' | 'medium' | 'long', team: 'hero' | 'villain') {
  switch (range) {
    case 'long':
      return getRangedGeometry(characterName, team);
    case 'medium':
      return getMediumRangeGeometry(characterName);
    case 'short':
      return getMeleeGeometry(characterName);
    default:
      return null;
  }
}

function getRangedGeometry(characterName: string, team: 'hero' | 'villain') {
  const direction = team === 'hero' ? -1 : 1;
  const attackColor = getAttackColor(characterName);

  switch (characterName) {
    case 'Iron Man':
      return (
        <group>
          {/* Repulsors beam */}
          <mesh position={[0, 0, direction * 8]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.15, 0.15, 16, 8]} />
            <meshBasicMaterial color={attackColor} transparent opacity={0.8} />
          </mesh>
          {/* Energy muzzle flash */}
          <mesh position={[0, 0, 0]}>
            <sphereGeometry args={[0.3]} />
            <meshBasicMaterial color="#FFFFFF" />
          </mesh>
        </group>
      );

    case 'Hawkeye':
      return (
        <group>
          {/* Arrow trail */}
          <mesh position={[0, 0, direction * 6]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.05, 0.05, 12, 8]} />
            <meshBasicMaterial color={attackColor} />
          </mesh>
          {/* Arrow tip */}
          <mesh position={[0, 0, direction * 12]}>
            <coneGeometry args={[0.1, 0.3, 6]} />
            <meshBasicMaterial color="#C0C0C0" />
          </mesh>
        </group>
      );

    case 'Vision':
      return (
        <group>
          {/* Mind Stone beam */}
          <mesh position={[0, 0, direction * 10]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.1, 0.1, 20, 8]} />
            <meshBasicMaterial color="#FFFF00" transparent opacity={0.9} />
          </mesh>
        </group>
      );

    case 'Captain Marvel':
      return (
        <group>
          {/* Energy blast */}
          <mesh position={[0, 0, direction * 8]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.2, 0.2, 16, 8]} />
            <meshBasicMaterial color={attackColor} transparent opacity={0.8} />
          </mesh>
          {/* Energy particles */}
          {Array.from({length: 6}).map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos((i / 6) * Math.PI * 2) * 0.3,
                0,
                Math.sin((i / 6) * Math.PI * 2) * 0.3 + direction * 4
              ]}
            >
              <sphereGeometry args={[0.08]} />
              <meshBasicMaterial color="#FFD700" />
            </mesh>
          ))}
        </group>
      );

    default:
      return (
        <group>
          {/* Generic ranged attack */}
          <mesh position={[0, 0, direction * 6]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.1, 0.1, 12, 8]} />
            <meshBasicMaterial color={attackColor} transparent opacity={0.7} />
          </mesh>
        </group>
      );
  }
}

function getMediumRangeGeometry(characterName: string) {
  const attackColor = getAttackColor(characterName);

  switch (characterName) {
    case 'Falcon':
      return (
        <group>
          {/* Wing projectiles */}
          {Array.from({length: 3}).map((_, i) => (
            <mesh key={i} position={[0, 0, -3 - i * 2]} rotation={[0, 0, Math.PI/4]}>
              <boxGeometry args={[0.3, 0.05, 0.05]} />
              <meshBasicMaterial color={attackColor} />
            </mesh>
          ))}
        </group>
      );

    case 'Winter Soldier':
      return (
        <group>
          {/* Gunfire muzzle flash */}
          <mesh position={[0, 0, -1]}>
            <coneGeometry args={[0.2, 0.5, 6]} />
            <meshBasicMaterial color="#FF6347" transparent opacity={0.8} />
          </mesh>
          {/* Bullet trail */}
          <mesh position={[0, 0, -4]} rotation={[Math.PI/2, 0, 0]}>
            <cylinderGeometry args={[0.02, 0.02, 8, 8]} />
            <meshBasicMaterial color="#FFD700" />
          </mesh>
        </group>
      );

    default:
      return (
        <group>
          {/* Generic medium range attack */}
          <mesh position={[0, 0, -3]}>
            <sphereGeometry args={[0.2]} />
            <meshBasicMaterial color={attackColor} />
          </mesh>
        </group>
      );
  }
}

function getMeleeGeometry(characterName: string) {
  const attackColor = getAttackColor(characterName);

  switch (characterName) {
    case 'Thor':
      return (
        <group>
          {/* Lightning sparks */}
          {Array.from({length: 4}).map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos((i / 4) * Math.PI * 2) * 1.5,
                0,
                Math.sin((i / 4) * Math.PI * 2) * 1.5
              ]}
              rotation={[0, 0, Math.PI/4]}
            >
              <boxGeometry args={[0.1, 1, 0.1]} />
              <meshBasicMaterial color="#87CEEB" />
            </mesh>
          ))}
        </group>
      );

    case 'Hulk':
      return (
        <group>
          {/* Smash impact */}
          <mesh position={[0, -0.5, 0]} rotation={[Math.PI/2, 0, 0]}>
            <torusGeometry args={[2, 0.2, 8, 32]} />
            <meshBasicMaterial color={attackColor} transparent opacity={0.7} />
          </mesh>
          {/* Debris */}
          {Array.from({length: 6}).map((_, i) => (
            <mesh
              key={i}
              position={[
                (Math.random() - 0.5) * 3,
                0,
                (Math.random() - 0.5) * 3
              ]}
            >
              <boxGeometry args={[0.2, 0.2, 0.2]} />
              <meshBasicMaterial color="#8B4513" />
            </mesh>
          ))}
        </group>
      );

    case 'Captain America':
      return (
        <group>
          {/* Shield bash effect */}
          <mesh rotation={[0, 0, 0]}>
            <cylinderGeometry args={[0.8, 0.8, 0.1, 16]} />
            <meshBasicMaterial color={attackColor} transparent opacity={0.8} />
          </mesh>
          {/* Impact stars */}
          {Array.from({length: 5}).map((_, i) => (
            <mesh
              key={i}
              position={[
                Math.cos((i / 5) * Math.PI * 2) * 1.2,
                0,
                Math.sin((i / 5) * Math.PI * 2) * 1.2
              ]}
            >
              <coneGeometry args={[0.1, 0.3, 4]} />
              <meshBasicMaterial color="#FFFFFF" />
            </mesh>
          ))}
        </group>
      );

    case 'Black Panther':
      return (
        <group>
          {/* Claw slashes */}
          {Array.from({length: 3}).map((_, i) => (
            <mesh
              key={i}
              position={[0, 0, 0]}
              rotation={[0, (i / 3) * Math.PI * 2, Math.PI/6]}
            >
              <boxGeometry args={[0.1, 2, 0.05]} />
              <meshBasicMaterial color={attackColor} />
            </mesh>
          ))}
        </group>
      );

    case 'Spider-Man':
      return (
        <group>
          {/* Web impact */}
          <mesh>
            <sphereGeometry args={[1]} />
            <meshBasicMaterial color="#FFFFFF" transparent opacity={0.6} />
          </mesh>
          {/* Web strands */}
          {Array.from({length: 6}).map((_, i) => (
            <mesh
              key={i}
              position={[0, 0, 0]}
              rotation={[0, (i / 6) * Math.PI * 2, Math.PI/4]}
            >
              <cylinderGeometry args={[0.02, 0.02, 2, 8]} />
              <meshBasicMaterial color="#C0C0C0" />
            </mesh>
          ))}
        </group>
      );

    default:
      return (
        <group>
          {/* Generic melee attack */}
          <mesh rotation={[Math.PI/2, 0, 0]}>
            <torusGeometry args={[1, 0.1, 8, 32]} />
            <meshBasicMaterial color={attackColor} transparent opacity={0.6} />
          </mesh>
        </group>
      );
  }
}

// Update functions for animated effects
function updateRangedAttackEffects(group: THREE.Group, time: number, characterName: string, team: 'hero' | 'villain') {
  const direction = team === 'hero' ? -1 : 1;
  
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      if (child.geometry instanceof THREE.CylinderGeometry) {
        // Beam pulsing effect
        const material = child.material as THREE.MeshBasicMaterial;
        material.opacity = 0.8 + Math.sin(time * 15) * 0.2;
        
        // Beam forward movement
        child.position.z = direction * (8 + Math.sin(time * 10) * 2);
      } else if (child.geometry instanceof THREE.SphereGeometry) {
        // Energy particles moving
        const radius = 0.3 + Math.sin(time * 8 + i) * 0.1;
        child.scale.setScalar(radius);
        child.position.z += direction * 0.5;
      }
    }
  });
}

function updateMediumRangeAttackEffects(group: THREE.Group, time: number, characterName: string) {
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      if (characterName === 'Falcon') {
        // Wing projectiles spinning
        child.rotation.z += 0.5;
        child.position.z -= 0.8;
      } else if (characterName === 'Winter Soldier') {
        // Muzzle flash flickering
        if (child.geometry instanceof THREE.ConeGeometry) {
          const material = child.material as THREE.MeshBasicMaterial;
          material.opacity = Math.random() > 0.5 ? 0.8 : 0.3;
        }
      }
    }
  });
}

function updateMeleeAttackEffects(group: THREE.Group, time: number, characterName: string) {
  group.children.forEach((child, i) => {
    if (child instanceof THREE.Mesh) {
      switch (characterName) {
        case 'Thor':
          // Lightning flickering
          if (child.geometry instanceof THREE.BoxGeometry) {
            const material = child.material as THREE.MeshBasicMaterial;
            material.opacity = Math.random() > 0.4 ? 1 : 0.2;
          }
          break;
          
        case 'Hulk':
          // Impact expanding
          if (child.geometry instanceof THREE.TorusGeometry) {
            child.scale.setScalar(1 + Math.sin(time * 8) * 0.5);
          } else if (child.geometry instanceof THREE.BoxGeometry) {
            // Debris movement
            child.position.y += 0.1;
            child.rotation.x += 0.1;
            child.rotation.z += 0.1;
          }
          break;
          
        case 'Captain America':
          // Shield rotating
          if (child.geometry instanceof THREE.CylinderGeometry) {
            child.rotation.z = time * 5;
          }
          break;
          
        case 'Spider-Man':
          // Web expanding
          if (child.geometry instanceof THREE.SphereGeometry) {
            child.scale.setScalar(1 + Math.sin(time * 6) * 0.3);
          }
          break;
      }
    }
  });
}

function getAttackColor(characterName: string): string {
  const colorMap: Record<string, string> = {
    'Iron Man': '#FF6347',
    'Thor': '#1E90FF',
    'Hulk': '#00FF00',
    'Captain America': '#4169E1',
    'Black Widow': '#8A2BE2',
    'Hawkeye': '#32CD32',
    'Spider-Man': '#FF0000',
    'Doctor Strange': '#9932CC',
    'Black Panther': '#9400D3',
    'Scarlet Witch': '#DC143C',
    'Vision': '#FFD700',
    'Ant-Man': '#FF0000',
    'Captain Marvel': '#FFD700',
    'Falcon': '#4169E1',
    'Winter Soldier': '#708090',
    'Thanos': '#800080',
    'Ultron': '#FF0000',
    'Loki': '#228B22',
    'Red Skull': '#DC143C',
    'Hela': '#000000',
    'Dormammu': '#FF4500',
    'Venom': '#000000',
    'Green Goblin': '#228B22',
    'Mysterio': '#9932CC',
    'Magneto': '#4B0082',
    'Kingpin': '#FFFFFF',
    'Killmonger': '#FFD700',
    'Ronan': '#4B0082',
    'Yellowjacket': '#FFFF00'
  };
  return colorMap[characterName] || '#FFFF00';
}